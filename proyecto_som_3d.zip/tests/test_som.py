"""Pruebas del aprendizaje, la BMU y la extensión a tres ejes."""
import numpy as np
import pytest
from som import SOM3D, SOMConfig
from dataset import load_base, matrix


def test_update_matches_kohonen_equation_in_three_dimensions():
    config = SOMConfig(grid_size=2, epochs=1, learning_rate=.5, sigma=1, seed=7)
    sample = np.array([[.2, .8]])
    model = SOM3D(config)
    initial = np.random.default_rng(7).random((8, 2))
    winner = np.abs(initial - sample[0]).sum(axis=1).argmin()
    d2 = np.square(model.coordinates - model.coordinates[winner]).sum(axis=1)
    expected = initial + .5 * np.exp(-d2 / 2)[:, None] * (sample[0] - initial)
    model.train(sample)
    np.testing.assert_allclose(model.weights, expected)
    assert set(map(tuple, model.coordinates)) == {(x, y, z) for x in range(2) for y in range(2) for z in range(2)}


@pytest.mark.parametrize("distance", ["manhattan", "euclidean"])
def test_exact_match_is_accepted_and_coordinates_are_final(distance):
    model = SOM3D(SOMConfig(grid_size=2, epochs=1, distance=distance))
    model.weights = np.ones((8, 2))
    model.weights[5] = [0., .5]
    assert model.map([[0., .5]]).tolist() == [model.coordinates[5].tolist()]
    assert model.quantization_error([[0., .5]]) == 0.


def test_seed_reproduces_weights_and_progress_finishes():
    data = matrix(load_base())
    progress = []
    config = SOMConfig(grid_size=3, epochs=15)
    first = SOM3D(config).train(data, lambda done, total: progress.append((done, total)))
    second = SOM3D(config).train(data)
    np.testing.assert_array_equal(first.weights, second.weights)
    np.testing.assert_array_equal(first.map(data), second.map(data))
    assert progress[-1] == (15, 15)
    assert len(progress) == 15
    assert first.quantization_error(data) < first.history[0]["Error de cuantización"]
    assert np.all((first.weights >= 0) & (first.weights <= 1))
    assert first.map(data).shape == (45, 3)


def test_nearest_compares_features_not_map_positions():
    model = SOM3D()
    indices, distances = model.nearest([0., 1.], [[1., 0.], [.1, .9], [0., 1.]])
    assert indices.tolist() == [2, 1, 0]
    np.testing.assert_allclose(distances, [0., .1, 1.])


def test_topographic_error_uses_face_adjacency():
    model = SOM3D(SOMConfig(grid_size=2))
    model.weights = np.full((8, 1), 1.)
    model.weights[0] = 0.
    model.weights[1] = .1
    assert model.topographic_error([[0.]]) == 0.
    model.weights[1] = 1.
    model.weights[7] = .1
    assert model.topographic_error([[0.]]) == 1.


@pytest.mark.parametrize("data", [[], [[float("nan")]], [[float("inf")]], [[-.1]], [[1.1]], [1, 2]])
def test_invalid_input_is_rejected(data):
    with pytest.raises(ValueError):
        SOM3D().train(data)


@pytest.mark.parametrize("kwargs", [{"grid_size": 1}, {"grid_size": 2.5}, {"epochs": 0}, {"learning_rate": 0}, {"sigma": float("nan")}, {"seed": -1}, {"distance": "bad"}])
def test_invalid_config_is_rejected(kwargs):
    with pytest.raises(ValueError):
        SOMConfig(**kwargs)


def test_projection_does_not_update_weights_and_rejects_wrong_dimension():
    model = SOM3D(SOMConfig(grid_size=2, epochs=2)).train([[0., 1.], [1., 0.]])
    before = model.weights.copy()
    model.map([[.2, .8]])
    np.testing.assert_array_equal(before, model.weights)
    with pytest.raises(ValueError):
        model.map([[0.]])
