import json
from dataclasses import asdict
import numpy as np
import pytest
from browser_backend import BrowserSession
from dataset import load_base, export_custom
from som import SOM3D, SOMConfig

@pytest.fixture
def session():
    base=load_base()
    model=SOM3D(SOMConfig(grid_size=3,epochs=3)).train([a['features'] for a in base])
    return BrowserSession({'base':base,'weights':model.weights.tolist(),
                           'config':asdict(model.config),'history':model.history})

def call(session,command,payload=None,progress=None):
    return json.loads(session.dispatch(json.dumps({'command':command,'payload':payload or {}}),progress))

def custom(session):
    return {**session.base[0],'name':'Oso de prueba','emoji':'🐻'}

def test_add_projects_with_same_weights_and_exact_bmu(session):
    weights=session.model.weights.copy()
    result=call(session,'add',{'animal':custom(session)})
    assert len(result['animals'])==46
    assert result['positions'][0]==result['positions'][-1]
    assert result['neighbors'][-1][0]=={'index':0,'distance':0.0}
    np.testing.assert_array_equal(weights,session.model.weights)

def test_duplicate_emoji_is_atomic(session):
    before=session.snapshot()
    animal={**custom(session),'emoji':'🐺'}
    with pytest.raises(ValueError,match='emoji'):call(session,'add',{'animal':animal})
    assert before==session.snapshot()

def test_invalid_train_is_atomic(session):
    before=session.snapshot()
    with pytest.raises(ValueError):call(session,'train',{'config':{'grid_size':1}})
    assert before==session.snapshot()

def test_train_changes_three_axes_and_progress(session):
    events=[]
    result=call(session,'train',{'config':{'grid_size':4,'epochs':6},'include_extra':False},lambda a,b:events.append((a,b)))
    assert events[-1]==(6,6)
    assert session.model.weights.shape==(64,20)
    assert all(len(p)==3 and all(0<=v<4 for v in p) for p in result['positions'])

def test_import_export_reset(session):
    call(session,'add',{'animal':custom(session)})
    exported=session.dispatch(json.dumps({'command':'export'}))
    call(session,'import',{'json':exported})
    assert len(session.extra)==1
    result=call(session,'reset')
    assert len(result['animals'])==45 and not result['extra']
    assert result['config']==asdict(SOMConfig())

def test_invalid_import_does_not_destroy_animals(session):
    call(session,'add',{'animal':custom(session)})
    before=session.snapshot()
    with pytest.raises(ValueError):call(session,'import',{'json':'{}'})
    assert before==session.snapshot()

def test_include_extra_retrains_on_add(session):
    call(session,'train',{'config':{'grid_size':3,'epochs':3},'include_extra':True})
    animal=custom(session)
    call(session,'add',{'animal':animal})
    expected=SOM3D(session.model.config).train([a['features'] for a in session.base+[animal]])
    np.testing.assert_array_equal(expected.weights,session.model.weights)

def test_html_has_no_missing_local_dependencies():
    from pathlib import Path
    import re
    html=Path('index.html').read_text()
    assert not re.search(r'<script[^>]+src=|<link[^>]+href=',html)
    assert '/*__' not in html
    assert 'browser_backend.py' in html and 'new Worker' in html
