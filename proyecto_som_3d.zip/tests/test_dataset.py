import json
from pathlib import Path
import pytest
from dataset import load_base, matrix, validate_collection, export_custom, import_custom
from features import FEATURES, ECOSYSTEMS
from visualization import make_figure
import numpy as np


def custom(name="Animal de prueba"):
    animal = load_base()[0].copy()
    animal["name"] = name
    animal["emoji"] = "🐻"
    return animal


def test_dataset_is_new_complete_and_uses_all_scale_levels():
    animals = load_base()
    assert len(animals) == 45
    assert len({a["emoji"] for a in animals}) == 45
    assert all(a["emoji"] != "🐾" for a in animals)
    assert len(FEATURES) == 20
    assert matrix(animals).shape == (45, 20)
    original = {"león", "puma", "tigre", "mono", "oso", "caballo", "jirafa", "elefante", "hipopótamo", "rinoceronte", "perro", "cerdo", "vaca", "pato", "ganzo", "ganso", "conejo", "cabra", "gato", "cebra", "gallina"}
    assert not original.intersection(a["name"].casefold() for a in animals)
    assert {a["ecosystem"] for a in animals} == set(ECOSYSTEMS)
    for col, feature in enumerate(FEATURES):
        assert set(matrix(animals)[:, col]) == set(feature.scale), feature.key
    assert {len(f.options) for f in FEATURES} == {2, 3, 4, 5}


def test_round_trip_preserves_schema_and_values():
    animals = [custom()]
    restored = import_custom(export_custom(animals).encode("utf-8"), load_base())
    assert restored == animals


@pytest.mark.parametrize("change", [{"name": " "}, {"name": "X"*61}, {"name": "hola\n"}, {"emoji": "abc"}, {"ecosystem": "desconocido"}, {"features": [0.]}, {"features": [.123]*20}, {"features": [True]*20}])
def test_bad_animal_is_rejected(change):
    animal = custom()
    animal.update(change)
    with pytest.raises(ValueError):
        validate_collection([animal])


def test_duplicate_names_are_rejected_case_insensitively_and_unicode_normalized():
    with pytest.raises(ValueError):
        validate_collection([custom(" LOBO GRIS ")], load_base())
    with pytest.raises(ValueError):
        validate_collection([custom("Águila nueva"), custom("A\u0301guila nueva")])


@pytest.mark.parametrize("raw", [b"not json", b"[]", b'{"schema_version": 8}', b"x"*1_000_001])
def test_import_rejects_invalid_files(raw):
    with pytest.raises(ValueError):
        import_custom(raw, load_base())


def test_import_rejects_wrong_feature_order():
    payload = json.loads(export_custom([custom()]))
    payload["feature_keys"].reverse()
    with pytest.raises(ValueError):
        import_custom(json.dumps(payload).encode(), load_base())


def test_shared_nodes_keep_true_coordinates_and_escape_user_names():
    animals = [custom("<b>Animal</b>"), custom("Otro animal")]
    fig = make_figure(animals, np.array([[1, 1, 1], [1, 1, 1]]), 3, labels=True, show_grid=False)
    assert len(fig.data) == 1
    assert list(fig.data[0].x) == [1]
    assert "+1" in fig.data[0].text[0]
    assert "&lt;b&gt;" in fig.data[0].customdata[0]
