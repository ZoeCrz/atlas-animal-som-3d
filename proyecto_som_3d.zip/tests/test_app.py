"""Pruebas de flujos reales con el ejecutor oficial de Streamlit."""
from pathlib import Path
from streamlit.testing.v1 import AppTest
from dataset import load_base
from features import FEATURES

APP = str(Path(__file__).parents[1] / "app.py")


def button(app, label):
    return next(b for b in app.button if b.label == label)


def test_initial_page_and_view_changes_do_not_retrain():
    app = AppTest.from_file(APP, default_timeout=30).run()
    assert not app.exception
    assert [m.value for m in app.metric][:2] == ["45", "20"]
    weights = app.session_state["model"].weights.copy()
    next(c for c in app.checkbox if c.label == "Ver retícula").uncheck().run()
    assert not app.exception
    assert (app.session_state["model"].weights == weights).all()


def test_incomplete_form_add_duplicate_reset_and_retrain():
    app = AppTest.from_file(APP, default_timeout=30).run()
    button(app, "Agregar y ubicar animal").click().run()
    assert app.error and not app.exception
    app.text_input(key="name_0").set_value("Animal nuevo de prueba")
    app.selectbox(key="ecosystem_0").select("Bosque templado")
    for feature, value in zip(FEATURES, load_base()[0]["features"]):
        app.selectbox(key=f"feature_{feature.key}_0").select(feature.scale.index(value))
    button(app, "Agregar y ubicar animal").click().run()
    assert not app.exception
    assert len(app.session_state["custom_animals"]) == 1
    assert app.metric[0].value == "46"
    assert app.session_state["selected_animal"] == "Animal nuevo de prueba"
    assert app.text_input(key="name_1").value == ""
    app.text_input(key="name_1").set_value(" lobo gris ")
    app.selectbox(key="ecosystem_1").select("Bosque templado")
    for feature in FEATURES:
        app.selectbox(key=f"feature_{feature.key}_1").select(0)
    button(app, "Agregar y ubicar animal").click().run()
    assert app.error and len(app.session_state["custom_animals"]) == 1
    next(s for s in app.slider if s.label == "Épocas").set_value(10)
    next(s for s in app.slider if s.label == "Lado del grid").set_value(3)
    next(c for c in app.checkbox if c.label == "Incluir animales agregados al entrenar").check()
    button(app, "Entrenar mapa").click().run()
    assert not app.exception
    assert app.session_state["config"].epochs == 10
    assert app.session_state["model"].coordinates.shape == (27, 3)
    assert app.session_state["include_custom"]
    button(app, "Limpiar formulario").click().run()
    assert len(app.session_state["custom_animals"]) == 1
    assert app.text_input(key="name_2").value == ""
    button(app, "Restaurar los 45 animales").click().run()
    assert not app.exception
    assert not app.session_state["custom_animals"]
    assert app.metric[0].value == "45"
