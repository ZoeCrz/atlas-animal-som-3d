"""Gráfico 3D sin desplazar artificialmente las coordenadas de la BMU."""
from collections import Counter
from html import escape
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from features import ECOSYSTEMS

COLORS = dict(zip(ECOSYSTEMS, ("#256d46", "#9b7b19", "#cc7832", "#5586b5", "#667c93", "#348f3a", "#058f9e", "#2463cc", "#985a9c", "#bd4675")))


def positions_table(animals, coordinates, base_count=45):
    counts = Counter(map(tuple, coordinates.tolist()))
    return pd.DataFrame([{"Emoji": a["emoji"], "Animal": a["name"], "Ecosistema": a["ecosystem"],
                          "X": int(c[0]), "Y": int(c[1]), "Z": int(c[2]),
                          "Animales en nodo": counts[tuple(c)],
                          "Origen": "Base" if i < base_count else "Agregado"}
                         for i, (a, c) in enumerate(zip(animals, coordinates))])


def make_figure(animals, coordinates, grid_size, labels=False, show_grid=True, selected_name=None):
    fig = go.Figure()
    if show_grid:
        # Tres familias de líneas forman la retícula cúbica, no una nube PCA sobre un SOM 2D.
        x, y, z = [], [], []
        for axis in range(3):
            other = [i for i in range(3) if i != axis]
            for a in range(grid_size):
                for b in range(grid_size):
                    start, end = [0, 0, 0], [0, 0, 0]
                    start[other[0]] = end[other[0]] = a
                    start[other[1]] = end[other[1]] = b
                    end[axis] = grid_size - 1
                    for values, k in ((x, 0), (y, 1), (z, 2)):
                        values.extend((start[k], end[k], None))
        fig.add_trace(go.Scatter3d(x=x, y=y, z=z, mode="lines", line={"color": "#d8e3df", "width": 1},
                                   hoverinfo="skip", showlegend=False))
    groups = {}
    for animal, coordinate in zip(animals, coordinates):
        groups.setdefault(tuple(int(v) for v in coordinate), []).append(animal)
    buckets = {}
    for coord, members in groups.items():
        ecosystems = {a["ecosystem"] for a in members}
        category = next(iter(ecosystems)) if len(ecosystems) == 1 else "Nodo mixto"
        buckets.setdefault(category, []).append((coord, members))
    for category, groups_in_bucket in buckets.items():
        xyz = np.asarray([c for c, _ in groups_in_bucket])
        text, hover, sizes, outlines = [], [], [], []
        for coord, members in groups_in_bucket:
            # WebGL no reproduce consistentemente fuentes de emojis a color.
            # Las etiquetas usan nombres; los emojis se conservan en hover y tablas HTML.
            short_name = members[0]["name"]
            if len(short_name) > 18:
                short_name = short_name[:17] + "…"
            text.append(short_name + (f" +{len(members)-1}" if len(members) > 1 else ""))
            # Los nombres ingresados por el usuario nunca se interpretan como HTML de hover.
            hover.append("<br>".join(f"{a['emoji']} {escape(a['name'])} · {escape(a['ecosystem'])}" for a in members))
            highlighted = any(a["name"] == selected_name for a in members)
            sizes.append(10 if highlighted else 6 + min(len(members), 5))
            outlines.append("#e17c00" if highlighted else "#ffffff")
        fig.add_trace(go.Scatter3d(x=xyz[:, 0], y=xyz[:, 1], z=xyz[:, 2],
            mode="markers+text" if labels else "markers", text=text, textposition="top center",
            textfont={"size": 11, "family": "Arial, sans-serif"},
            customdata=hover, name=category,
            marker={"size": sizes, "color": COLORS.get(category, "#566b63"),
                    "line": {"color": outlines, "width": 2}, "opacity": .95},
            hovertemplate="%{customdata}<br>BMU (%{x}, %{y}, %{z})<extra></extra>"))
    axis = {"tickmode": "linear", "dtick": 1, "range": [-.4, grid_size-.6],
            "showbackground": True, "backgroundcolor": "#f8faf9", "gridcolor": "#e1e9e5"}
    fig.update_layout(height=580, margin={"l": 0, "r": 0, "t": 5, "b": 0},
        scene={"xaxis": dict(axis, title="X · neurona"), "yaxis": dict(axis, title="Y · neurona"),
               "zaxis": dict(axis, title="Z · neurona"), "aspectmode": "cube",
               "camera": {"eye": {"x": 1.6, "y": 1.6, "z": 1.3}}},
        legend={"orientation": "h", "font": {"size": 11}}, uirevision=f"grid-{grid_size}",
        paper_bgcolor="#ffffff", font={"family": "Arial, sans-serif", "color": "#19352b"})
    return fig
