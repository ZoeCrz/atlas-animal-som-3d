'use strict';
const EMBED=JSON.parse(document.getElementById('embeddedData').textContent);
const $=id=>document.getElementById(id);
const esc=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const emojiNames={'🦡':'Tejón','🦝':'Mapache','🦍':'Gorila','🦧':'Orangután','🐼':'Panda','🐨':'Koala','🐗':'Jabalí','🐏':'Carnero','🐑':'Oveja','🐂':'Buey','🐃':'Búfalo','🦓':'Cebra','🦒':'Jirafa','🐘':'Elefante','🦏':'Rinoceronte','🦛':'Hipopótamo','🦆':'Pato','🪿':'Ganso','🕊️':'Paloma','🐦':'Ave','🐓':'Gallo','🐒':'Mono','🐕':'Perro','🐈':'Gato','🐎':'Caballo','🐐':'Cabra','🐖':'Cerdo','🐇':'Conejo','🐻':'Oso'};
let state=EMBED.snapshot,selected=0,worker=null,ready=false,busy=false,requestId=0;
let yaw=.65,pitch=.36,zoom=1,groups=[],drag=null,toastTimer,workerUrl;
const pending=new Map();
const STORAGE='atlas-animal-v2';
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,6000);}
function status(message,kind='ready'){$('statusText').textContent=message;$('statusDot').className='status-dot '+(kind==='ready'?'':kind);}
function lock(value){busy=value;document.querySelectorAll('.motor').forEach(b=>b.disabled=!ready||busy);$('importInput').disabled=!ready||busy;}
function persist(){try{localStorage.setItem(STORAGE,JSON.stringify({schema_version:1,feature_keys:EMBED.features.map(f=>f.key),animals:state.extra}));}catch{toast('No se pudo guardar en este navegador. Usa “Guardar mis animales” para conservarlos.');}}
function rpc(command,payload={}){if(!ready||busy)return Promise.reject(new Error('El motor aún se está preparando.'));lock(true);status(command==='train'||command==='reset'?'Entrenando el mapa…':'Actualizando animales…','loading');$('trainProgress').hidden=false;$('trainProgress').value=0;return new Promise((resolve,reject)=>{const id=++requestId;pending.set(id,{resolve,reject});worker.postMessage({id,command,payload});});}
async function apply(command,payload={},message){try{const result=await rpc(command,payload);state=result;selected=Math.min(selected,state.animals.length-1);persist();render();if(message)toast(message);return true;}catch(error){toast(error.message);return false;}}
const workerCode=`
let py;
self.onmessage=async({data})=>{
 if(data.type==='init'){
  try{
   const {loadPyodide}=await import('https://cdn.jsdelivr.net/pyodide/v314.0.7/full/pyodide.mjs');
   py=await loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v314.0.7/full/'});
   self.postMessage({type:'loading',message:'Cargando herramientas de cálculo…'});
   await py.loadPackage('numpy');
   for(const [name,source] of Object.entries(data.sources))py.FS.writeFile('/home/pyodide/'+name,source);
   py.globals.set('_initial_json',JSON.stringify(data.initial));
   await py.runPythonAsync('import json\\nfrom browser_backend import BrowserSession\\n_session = BrowserSession(json.loads(_initial_json))');
   self.postMessage({type:'ready'});
  }catch(error){self.postMessage({type:'fatal',message:String(error)});}
  return;
 }
 try{
  py.globals.set('_request_json',JSON.stringify(data));
  py.globals.set('_progress',(current,total)=>self.postMessage({type:'progress',value:current/total*100,current,total}));
  const raw=await py.runPythonAsync('_session.dispatch(_request_json, _progress)');
  self.postMessage({type:'result',id:data.id,result:JSON.parse(raw)});
 }catch(error){self.postMessage({type:'error',id:data.id,message:String(error).split('ValueError:').pop().trim()});}
};`;
function startWorker(){
 if(worker)worker.terminate();if(workerUrl)URL.revokeObjectURL(workerUrl);ready=false;lock(false);$('retryButton').hidden=true;status('Preparando Python…','loading');
 workerUrl='data:text/javascript;charset=utf-8,'+encodeURIComponent(workerCode);worker=new Worker(workerUrl,{type:'module',credentials:'omit'});
 const timer=setTimeout(()=>{if(!ready){status('La carga está tardando. Revisa tu conexión a internet.','error');$('retryButton').hidden=false;}},60000);
 worker.onmessage=async({data})=>{
  if(data.type==='loading')status(data.message,'loading');
  if(data.type==='ready'){
   clearTimeout(timer);ready=true;lock(false);status('Listo para explorar y entrenar');
   let saved;try{saved=localStorage.getItem(STORAGE);}catch{}
   if(saved){try{const parsed=JSON.parse(saved);if(parsed.animals?.length)await apply('import',{json:saved},'Se recuperaron tus animales guardados.');}catch{toast('No se pudieron recuperar los animales guardados. Puedes importarlos desde un JSON.');}}
  }
  if(data.type==='progress'){$('trainProgress').value=data.value;status('Entrenando · época '+data.current+' de '+data.total,'loading');}
  if(data.type==='fatal'){clearTimeout(timer);status('No se pudo cargar Python. Revisa internet y reintenta.','error');$('retryButton').hidden=false;lock(false);}
  if(data.type==='result'||data.type==='error'){
   const promise=pending.get(data.id);if(!promise)return;pending.delete(data.id);lock(false);$('trainProgress').hidden=true;status('Listo para explorar y entrenar');
   if(data.type==='result')promise.resolve(data.result);else promise.reject(new Error(data.message));
  }
 };
 worker.onerror=()=>{clearTimeout(timer);ready=false;lock(false);status('No se pudo iniciar Python. Reintenta con internet.','error');$('retryButton').hidden=false;for(const p of pending.values())p.reject(new Error('El motor se interrumpió. Reintenta cargar Python.'));pending.clear();};
 worker.postMessage({type:'init',sources:EMBED.sources,initial:EMBED.initial});
}
function matches(animal){const query=$('search').value.trim().toLocaleLowerCase('es');return animal.name.toLocaleLowerCase('es').includes(query)&&(!$('ecosystemFilter').value||animal.ecosystem===$('ecosystemFilter').value);}
function visibleIndices(){return state.animals.map((a,i)=>matches(a)?i:-1).filter(i=>i>=0);}
function selectAnimal(index){selected=index;render();}
function render(){
 const visible=visibleIndices();$('animalCount').textContent=state.animals.length;$('catalogCount').textContent=visible.length;$('shownCount').textContent=visible.length+' animales en el mapa';
 $('animalList').replaceChildren();
 for(const i of visible){const a=state.animals[i],b=document.createElement('button');b.className='animal-row'+(i===selected?' active':'');b.setAttribute('aria-pressed',String(i===selected));b.innerHTML='<span class="list-emoji">'+esc(a.emoji)+'</span><span><span class="row-name">'+esc(a.name)+'</span><span class="row-ecosystem">'+esc(a.ecosystem)+'</span></span><span class="row-arrow" aria-hidden="true">›</span>';b.onclick=()=>selectAnimal(i);$('animalList').append(b);}
 if(!visible.length){const p=document.createElement('p');p.className='small-note';p.textContent='No encontramos animales con esta búsqueda.';$('animalList').append(p);}
 const grouped=new Map();for(const i of visible){const key=state.positions[i].join(',');if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(i);}
 groups=[];$('nodes').replaceChildren();for(const indices of grouped.values()){
  const representative=indices.includes(selected)?selected:indices[0],a=state.animals[representative];const b=document.createElement('button');b.className='node'+(indices.includes(selected)?' selected':'');b.innerHTML=esc(a.emoji)+(indices.length>1?'<span class="badge">'+indices.length+'</span>':'');b.title=indices.map(i=>state.animals[i].name).join(' · ');b.setAttribute('aria-label',b.title+'; posición '+state.positions[representative].join(', '));b.onclick=()=>{if(drag?.moved)return;selectAnimal(representative);};$('nodes').append(b);groups.push({indices,position:state.positions[representative],button:b});
 }
 $('emptyMap').hidden=visible.length>0;renderInspector();drawMap();
}
function renderInspector(){
 const a=state.animals[selected],pos=state.positions[selected];if(!a)return;
 const same=state.positions.map((p,i)=>p.every((v,j)=>v===pos[j])?i:-1).filter(i=>i>=0&&i!==selected);
 $('inspector').innerHTML='<div><div class="identity"><div class="identity-emoji">'+esc(a.emoji)+'</div><div><span class="eyebrow dark">ANIMAL SELECCIONADO</span><h3>'+esc(a.name)+'</h3><small>'+esc(a.ecosystem)+(a.scientific_name?' · <i>'+esc(a.scientific_name)+'</i>':'')+'</small><br><span class="position-pill">Posición · X '+pos[0]+' &nbsp; Y '+pos[1]+' &nbsp; Z '+pos[2]+'</span></div></div>'+(same.length?'<div class="node-members">Comparte esta posición con:<br>'+same.map(i=>'<button data-animal="'+i+'">'+esc(state.animals[i].emoji)+' '+esc(state.animals[i].name)+'</button>').join('')+'</div>':'')+'</div><div><div class="similar-title"><h3>Sus parecidos más cercanos</h3><span>Según los 20 rasgos</span></div><div class="neighbors">'+state.neighbors[selected].map(n=>'<button class="neighbor" data-animal="'+n.index+'" title="Diferencia de rasgos: '+(n.distance*100).toFixed(1)+' %"><span>'+esc(state.animals[n.index].emoji)+'</span>'+esc(state.animals[n.index].name)+'</button>').join('')+'</div></div><details class="traits"><summary>Ver sus 20 características</summary><div class="trait-grid">'+EMBED.features.map((f,i)=>'<div>'+esc(f.label)+'<strong>'+esc(f.options[f.scale.indexOf(a.features[i])])+'</strong></div>').join('')+'</div></details>';
 $('inspector').querySelectorAll('[data-animal]').forEach(b=>b.onclick=()=>selectAnimal(Number(b.dataset.animal)));
}
// Rotación ortográfica del cubo real. No se añaden desplazamientos a las BMU.
function project(point,width,height){const side=state.config.grid_size-1;const p=point.map(v=>v/side*2-1);const x=p[0]*Math.cos(yaw)-p[2]*Math.sin(yaw),z=p[0]*Math.sin(yaw)+p[2]*Math.cos(yaw);const y=p[1]*Math.cos(pitch)-z*Math.sin(pitch);const depth=p[1]*Math.sin(pitch)+z*Math.cos(pitch);const scale=Math.min(width*.23,height*.27)*zoom;return{x:width/2+x*scale,y:height/2-y*scale,depth};}
function drawMap(){
 const stage=$('mapStage'),canvas=$('mapCanvas'),w=stage.clientWidth,h=stage.clientHeight;if(!w||!h)return;const ratio=devicePixelRatio||1;canvas.width=w*ratio;canvas.height=h*ratio;const ctx=canvas.getContext('2d');ctx.scale(ratio,ratio);ctx.clearRect(0,0,w,h);const s=state.config.grid_size-1;
 function line(a,b,color,width=1){const p=project(a,w,h),q=project(b,w,h);ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();}
 // Tres caras de referencia y aristas del cubo, con gradación discreta.
 for(let i=0;i<=s;i++){line([i,0,0],[i,0,s],'#dfe8d5');line([0,0,i],[s,0,i],'#dfe8d5');line([0,i,0],[0,i,s],'#e5ebde');line([0,0,i],[0,s,i],'#e5ebde');line([i,0,0],[i,s,0],'#e5ebde');line([0,i,0],[s,i,0],'#e5ebde');}
 for(let axis=0;axis<3;axis++)for(let a=0;a<2;a++)for(let b=0;b<2;b++){let p=[0,0,0],q=[0,0,0];const other=[0,1,2].filter(i=>i!==axis);p[other[0]]=q[other[0]]=a*s;p[other[1]]=q[other[1]]=b*s;q[axis]=s;line(p,q,'#c8d7bd',1.2);}
 const axes=[[[s,0,0],'X'],[[0,s,0],'Y'],[[0,0,s],'Z']];ctx.font='600 11px system-ui';ctx.fillStyle='#779268';for(const [p,label] of axes){const xy=project(p,w,h);ctx.fillText(label+' · '+s,xy.x+9,xy.y+12);}const zero=project([0,0,0],w,h);ctx.fillText('0',zero.x-12,zero.y+14);
 const projected=groups.map(g=>({...g,p:project(g.position,w,h)})).sort((a,b)=>a.p.depth-b.p.depth);projected.forEach((g,i)=>{g.button.style.left=g.p.x+'px';g.button.style.top=g.p.y+'px';g.button.style.zIndex=i+1;});
}
$('mapStage').addEventListener('pointerdown',e=>{if(e.target.closest('.node,.zoom-controls'))return;drag={x:e.clientX,y:e.clientY,yaw,pitch,moved:false};$('mapStage').setPointerCapture(e.pointerId);});
$('mapStage').addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;yaw=drag.yaw+dx*.009;pitch=Math.max(-1.15,Math.min(1.15,drag.pitch+dy*.007));drawMap();});
function stopDrag(){drag=null;}$('mapStage').addEventListener('pointerup',stopDrag);$('mapStage').addEventListener('pointercancel',stopDrag);
$('mapStage').addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.55,Math.min(1.65,zoom*Math.exp(-e.deltaY*.001)));drawMap();},{passive:false});
$('zoomIn').onclick=()=>{zoom=Math.min(1.65,zoom*1.15);drawMap();};$('zoomOut').onclick=()=>{zoom=Math.max(.55,zoom/1.15);drawMap();};
$('homeButton').onclick=()=>{yaw=.65;pitch=.36;zoom=1;drawMap();};new ResizeObserver(drawMap).observe($('mapStage'));
$('search').oninput=render;$('ecosystemFilter').onchange=render;
EMBED.ecosystems.forEach(eco=>{for(const id of ['ecosystemFilter','addEcosystem']){const opt=document.createElement('option');opt.value=eco;opt.textContent=eco;$(id).append(opt);}});
$('addEcosystem').insertAdjacentHTML('afterbegin','<option value="" selected>Selecciona un ecosistema</option>');
const featureGroups=[['Cuerpo y tamaño',[0,1,2,3]],['Dónde y cómo se mueve',[4,5,6,7,8]],['Alimentación y forma de vida',[9,10,11,12]],['Adaptaciones y biología',[13,14,15,16,17,18,19]]];
$('featureFields').innerHTML=featureGroups.map(([title,indices],g)=>'<details class="feature-group" '+(g===0?'open':'')+'><summary>'+esc(title)+' · '+indices.length+' rasgos</summary><div class="form-grid">'+indices.map(i=>{const f=EMBED.features[i];return '<label>'+esc(f.label)+'<select name="feature_'+i+'" required><option value="">Selecciona…</option>'+f.options.map((o,j)=>'<option value="'+f.scale[j]+'">'+esc(o)+'</option>').join('')+'</select><small>'+esc(f.help)+'</small></label>';}).join('')+'</div></details>').join('');
function pickEmojis(){const used=new Set(state.animals.map(a=>a.emoji));$('emojiPicker').replaceChildren();for(const emoji of EMBED.emojis.filter(e=>!used.has(e))){const b=document.createElement('button');b.type='button';b.className='emoji-option';b.textContent=emoji;b.setAttribute('aria-label',emojiNames[emoji]||'Animal '+emoji);b.title=emojiNames[emoji]||emoji;b.onclick=()=>{$('addForm').elements.emoji.value=emoji;$('emojiCaption').textContent=(emojiNames[emoji]||'Animal')+' · '+emoji;$('emojiPicker').querySelectorAll('button').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b));});};$('emojiPicker').append(b);}}
$('addButton').onclick=()=>{$('addForm').reset();pickEmojis();$('formError').hidden=true;$('addDialog').showModal();};
$('addForm').onreset=()=>{setTimeout(()=>{$('addForm').elements.emoji.value='';$('emojiCaption').textContent='Selecciona el animal que corresponda a su nombre.';$('emojiPicker').querySelectorAll('button').forEach(b=>b.classList.remove('active'));$('formError').hidden=true;},0);};
$('addForm').addEventListener('invalid',e=>{e.target.closest('details')?.setAttribute('open','');},true);
$('addForm').onsubmit=async e=>{e.preventDefault();const form=e.target,emoji=form.elements.emoji.value;if(!emoji){$('formError').textContent='Selecciona el emoji de tu animal.';$('formError').hidden=false;return;}const animal={name:form.elements.name.value,emoji,ecosystem:form.elements.ecosystem.value,features:EMBED.features.map((_,i)=>Number(form.elements['feature_'+i].value))};$('addDialog').close();const ok=await apply('add',{animal},'Animal agregado y ubicado en el mapa.');if(ok){selected=state.animals.length-1;$('search').value='';$('ecosystemFilter').value='';render();$('inspector').scrollIntoView({behavior:'smooth',block:'nearest'});}else{$('formError').textContent='Revisa los datos y vuelve a intentarlo.';$('formError').hidden=false;$('addDialog').showModal();}};
$('trainButton').onclick=()=>{const f=$('trainForm');for(const [k,v] of Object.entries(state.config))f.elements[k].value=v;f.elements.include_extra.checked=state.include_extra;$('trainDialog').showModal();};
$('trainForm').onsubmit=e=>{e.preventDefault();const f=e.target,config={};for(const k of ['epochs','grid_size','learning_rate','sigma','seed'])config[k]=Number(f.elements[k].value);config.distance=f.elements.distance.value;$('trainDialog').close();apply('train',{config,include_extra:f.elements.include_extra.checked},'Nuevo entrenamiento completo. Explora los cambios.');};
$('helpButton').onclick=()=>$('helpDialog').showModal();document.querySelectorAll('dialog .close').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
$('exportButton').onclick=()=>{if(!state.extra.length){toast('Todavía no has agregado animales.');return;}const payload={schema_version:1,feature_keys:EMBED.features.map(f=>f.key),animals:state.extra},url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='mis-animales.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
$('importInput').onchange=async e=>{const file=e.target.files[0];e.target.value='';if(!file)return;if(file.size>1000000){toast('El archivo no puede superar 1 MB.');return;}if(state.extra.length&&!confirm('La importación reemplazará tus animales agregados. ¿Continuar?'))return;await apply('import',{json:await file.text()},'Animales importados y ubicados.');};
$('resetButton').onclick=()=>{if(!confirm('Se eliminarán tus animales agregados y se restaurará el entrenamiento inicial. ¿Continuar?'))return;selected=0;$('search').value='';$('ecosystemFilter').value='';apply('reset',{},'Se restauró el mapa inicial.');};
$('retryButton').onclick=startWorker;
render();startWorker();
