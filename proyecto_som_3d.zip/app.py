"""Interfaz Streamlit: formulario arriba, progreso y mapa junto a posiciones abajo.

Ejecutar: python -m streamlit run app.py
El estado de cada visitante es independiente y los animales se exportan como JSON.
"""
import json
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from dataset import (load_base, matrix, records, validate_collection, export_custom,
                     import_custom, MAX_CUSTOM_ANIMALS)
from features import FEATURES, ECOSYSTEMS, EMOJIS, feature_dictionary
from som import SOM3D, SOMConfig
from visualization import make_figure, positions_table

ROOT = Path(__file__).parent
st.set_page_config(page_title="Mapa autoorganizado 3D", page_icon="🦊", layout="wide")
st.markdown("""<style>
 .block-container {padding-top: 2rem; padding-bottom: 2rem; max-width: 1800px;}
 h1 {font-size: 2rem !important;} h2 {font-size: 1.3rem !important;}
 h3 {font-size: 1.12rem !important;}
 .st-key-project_card {border-top: 4px solid #0b9163; padding: 1rem; border-radius: 6px;}
 .st-key-animal_form {border-top: 4px solid #e79829;}
 [data-testid="stMetricValue"] {font-size: 1.65rem;}
 </style>""", unsafe_allow_html=True)

base = load_base()
project = json.loads((ROOT / "data" / "proyecto.json").read_text(encoding="utf-8"))
if "custom_animals" not in st.session_state:
    st.session_state.custom_animals = []
if "config" not in st.session_state:
    st.session_state.config = SOMConfig()
    st.session_state.include_custom = False
if "form_generation" not in st.session_state:
    st.session_state.form_generation = 0


def reset_form():
    # Cambiar las claves crea un formulario limpio sin borrar animales ni reentrenar.
    st.session_state.form_generation += 1


def restore_base():
    st.session_state.custom_animals = []
    st.session_state.form_generation += 1
    st.session_state.pop("selected_animal", None)
    st.session_state.notice = "Se restauraron los 45 animales base."


with st.sidebar:
    st.header("Entrenamiento")
    st.caption("Modifica los valores y pulsa Entrenar mapa para aplicarlos.")
    current = st.session_state.config
    with st.form("training_form"):
        epochs = st.slider("Épocas", 10, 300, current.epochs, 10)
        grid = st.slider("Lado del grid", 2, 10, current.grid_size,
                         help="Grid cúbico: lado³ neuronas, con X, Y y Z.")
        alpha = st.slider("Tasa de aprendizaje", .05, 1., current.learning_rate, .05)
        sigma = st.slider("Radio inicial de vecindad", .5, 10., current.sigma, .5)
        seed = st.number_input("Semilla aleatoria", 0, 2**32 - 1, current.seed, 1)
        distance = st.selectbox("Distancia", ["manhattan", "euclidean"],
                                index=0 if current.distance == "manhattan" else 1,
                                format_func=lambda d: "Manhattan · como el original" if d == "manhattan" else "Euclidiana")
        include = st.checkbox("Incluir animales agregados al entrenar", st.session_state.include_custom,
                              help="Sin esta opción, los animales nuevos solo se ubican en el mapa existente.")
        train_pressed = st.form_submit_button("Entrenar mapa", type="primary", width="stretch")
    if train_pressed:
        st.session_state.config = SOMConfig(grid, epochs, alpha, sigma, int(seed), distance)
        st.session_state.include_custom = include
        st.session_state.pop("model_signature", None)
    st.caption("Menor error de cuantización significa un mejor ajuste a los rasgos; no es una exactitud de clasificación.")
    st.divider()
    st.subheader("Conservar tus animales")
    st.caption("Los agregados viven en esta sesión. Descarga el JSON antes de cerrarla.")
    st.download_button("Descargar animales agregados", export_custom(st.session_state.custom_animals),
                       "mis_animales.json", "application/json", width="stretch")
    uploaded = st.file_uploader("Restaurar desde JSON", type=["json"], help="Archivo exportado por esta aplicación. Máximo 1 MB.")
    if st.button("Importar animales", disabled=uploaded is None, width="stretch"):
        try:
            st.session_state.custom_animals = import_custom(uploaded.getvalue(), base)
            st.session_state.pop("selected_animal", None)
            st.session_state.notice = "Animales importados. La importación reemplaza los agregados de esta sesión."
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))
    with st.expander("Restaurar dataset base"):
        st.caption("Quita todos los animales agregados. Puedes respaldarlos en JSON antes de continuar.")
        st.button("Restaurar los 45 animales", on_click=restore_base, width="stretch")

st.title("Mapa autoorganizado de animales")
st.caption("Explora cómo un SOM organiza 20 características en una cuadrícula tridimensional.")
if "notice" in st.session_state:
    st.success(st.session_state.pop("notice"))

info, form_area = st.columns([1, 3], gap="large")
with info:
    with st.container(border=True, key="project_card"):
        st.subheader(project["titulo"])
        st.write(f"**Materia:** {project['materia']}")
        st.write(f"**Docente:** {project['docente']}")
        if project["integrantes"]:
            st.write("**Integrantes**")
            for member in project["integrantes"]:
                st.write(str(member))
        st.divider()
        st.write("**1.** Entrena el mapa con los controles de la izquierda.")
        st.write("**2.** Define un animal y sus 20 características.")
        st.write("**3.** Gira el mapa y consulta su posición X, Y, Z.")
        st.caption("Dataset educativo: categorías aproximadas para estudiar el algoritmo.")
    st.button("Limpiar formulario", on_click=reset_form, width="stretch")

with form_area:
    generation = st.session_state.form_generation
    # Como en el PHP, los selectores se crean desde un diccionario de rasgos.
    # st.form agrupa los cambios y evita entrenamientos parciales al llenar campos.
    with st.form("animal_form"):
        st.subheader("Agregar un animal")
        name_col, emoji_col, ecosystem_col = st.columns([2, 1, 2])
        name = name_col.text_input("Nombre del animal", max_chars=60, key=f"name_{generation}", placeholder="Ejemplo: mi animal de prueba")
        used_emojis = {a["emoji"] for a in base + st.session_state.custom_animals}
        available_emojis = [e for e in EMOJIS if e not in used_emojis]
        emoji = emoji_col.selectbox("Emoji", available_emojis,
            index=len(available_emojis)-1 if available_emojis else None,
            key=f"emoji_{generation}", disabled=not available_emojis,
            help="Elige un emoji del propio animal. Cada emoji identifica un animal distinto.")
        ecosystem = ecosystem_col.selectbox("Ecosistema", ECOSYSTEMS, key=f"ecosystem_{generation}", index=None, placeholder="Selecciona un ecosistema")
        values = []
        for start in range(0, len(FEATURES), 5):
            columns = st.columns(5)
            for column, feature in zip(columns, FEATURES[start:start+5]):
                choice = column.selectbox(feature.label, range(len(feature.options)), index=None,
                    format_func=lambda i, f=feature: f"{f.options[i]} · {f.scale[i]:g}",
                    key=f"feature_{feature.key}_{generation}", help=feature.help, placeholder="Selecciona")
                values.append(None if choice is None else feature.scale[choice])
        st.caption("Emojis Unicode compatibles con iOS, Android y Windows; su dibujo varía según el sistema.")
        add_pressed = st.form_submit_button("Agregar y ubicar animal", type="primary")
    if add_pressed:
        try:
            if ecosystem is None or any(v is None for v in values):
                raise ValueError("Selecciona el ecosistema y las 20 características antes de agregar el animal.")
            if len(st.session_state.custom_animals) >= MAX_CUSTOM_ANIMALS:
                raise ValueError(f"Se permiten hasta {MAX_CUSTOM_ANIMALS} animales agregados por sesión.")
            new_animal = validate_collection([{"name": name, "emoji": emoji, "ecosystem": ecosystem,
                                                "features": values}], base + st.session_state.custom_animals)[0]
            st.session_state.custom_animals.append(new_animal)
            st.session_state.selected_animal = new_animal["name"]
            st.session_state.notice = f"{new_animal['emoji']} {new_animal['name']} agregado al mapa."
            st.session_state.form_generation += 1
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

animals = base + st.session_state.custom_animals
all_data = matrix(animals)
training_data = all_data if st.session_state.include_custom else matrix(base)
config = st.session_state.config
signature = (tuple(asdict(config).values()), training_data.tobytes())
progress_bar = st.progress(0, text="Preparando el mapa")
if st.session_state.get("model_signature") != signature:
    # El estado persiste entre cambios visuales; no se reentrena al filtrar o girar el mapa.
    def update_progress(epoch, total):
        progress_bar.progress(epoch / total, text=f"Entrenando · época {epoch} de {total}")
    st.session_state.model = SOM3D(config).train(training_data, progress=update_progress)
    st.session_state.model_signature = signature
model = st.session_state.model
progress_bar.progress(1., text=f"Mapa listo · {config.epochs} épocas · {len(training_data)} animales de entrenamiento")

# Se calculan TODAS las posiciones después de la última actualización de pesos.
coordinates = model.map(all_data)
positions = positions_table(animals, coordinates)
occupied = len(set(map(tuple, coordinates)))
m1, m2, m3, m4, m5 = st.columns(5)
m1.metric("Animales", len(animals))
m2.metric("Características", len(FEATURES))
m3.metric("Neuronas del grid", f"{config.grid_size}³ = {config.grid_size**3}")
m4.metric("Error de cuantización", f"{model.quantization_error(training_data):.4f}", help="Distancia promedio normalizada a la neurona ganadora, sobre los animales usados al entrenar.")
m5.metric("Nodos ocupados", occupied, help="Un mismo nodo puede contener varios animales similares.")

with st.expander("Cómo leer el resultado"):
    st.write("Cada animal es un vector de 20 valores. El SOM aprende un prototipo por neurona y asigna el animal a la neurona más parecida, llamada BMU. X, Y y Z son índices de esa neurona, desde 0 hasta lado − 1; no son coordenadas geográficas ni rasgos como masa o longitud.")
    st.write("Los animales con rasgos parecidos pueden quedar cerca o compartir un nodo. Cada punto reúne todos los animales de esa neurona; pasa el cursor para verlos. No se altera su ubicación para separarlos. Los colores indican el ecosistema de referencia, que no se usa como entrada del entrenamiento.")
    st.write("La cercanía del mapa es orientativa. Cambiar parámetros puede reorganizarlo y un error bajo no garantiza que todos los vecinos sean similares.")

map_area, list_area = st.columns([2, 1], gap="large")
with map_area:
    st.subheader("Mapa SOM en tres dimensiones")
    st.caption("Arrastra para girar · usa la rueda para acercar · pasa el cursor por los puntos")
    filter_col, labels_col, grid_col = st.columns([3, 1, 1])
    selected_ecosystems = filter_col.multiselect("Filtrar ecosistemas", ECOSYSTEMS, default=[], placeholder="Todos los ecosistemas")
    labels = labels_col.checkbox("Ver nombres", False)
    show_grid = grid_col.checkbox("Ver retícula", True)
    visible = [i for i, animal in enumerate(animals) if not selected_ecosystems or animal["ecosystem"] in selected_ecosystems]
    figure = make_figure([animals[i] for i in visible], coordinates[visible], config.grid_size,
                        labels=labels, show_grid=show_grid, selected_name=st.session_state.get("selected_animal"))
    st.plotly_chart(figure, width="stretch", key="som_chart", config={"displaylogo": False})
    st.caption(f"{len(visible)} animales visibles · {len(animals) - occupied} asignaciones adicionales a nodos compartidos en el dataset completo.")
    st.download_button("Descargar mapa interactivo HTML", figure.to_html(include_plotlyjs=True, full_html=True),
                       "mapa_som_3d.html", "text/html", help="Se abre sin Python ni conexión a internet. Conserva el filtro visible.")
with list_area:
    st.subheader("Animales y posiciones")
    search = st.text_input("Buscar por nombre", placeholder="Escribe parte del nombre")
    visible_positions = positions.iloc[visible]
    if search.strip():
        visible_positions = visible_positions[visible_positions["Animal"].str.contains(search.strip(), case=False, regex=False)]
    st.dataframe(visible_positions[["Emoji", "Animal", "X", "Y", "Z", "Origen"]], hide_index=True, height=570, width="stretch")
    st.download_button("Descargar posiciones CSV", positions.to_csv(index=False).encode("utf-8-sig"), "posiciones_som_3d.csv", "text/csv", width="stretch")

st.subheader("Explorar un animal")
selected_name = st.selectbox("Animal a consultar", [a["name"] for a in animals], key="selected_animal")
selected_index = next(i for i, a in enumerate(animals) if a["name"] == selected_name)
selected = animals[selected_index]
detail, similar = st.columns([1, 1])
with detail:
    st.write(f"**{selected['emoji']} {selected['name']}** · {selected['ecosystem']} · BMU {tuple(int(v) for v in coordinates[selected_index])}")
    st.dataframe(pd.DataFrame([{"Característica": f.label, "Opción": f.options[f.scale.index(v)], "Valor": v}
                              for f, v in zip(FEATURES, selected["features"])]), hide_index=True, height=300, width="stretch")
with similar:
    # La similitud se calcula en los 20 rasgos, no por distancia visual en el gráfico.
    others = [i for i in range(len(animals)) if i != selected_index]
    indices, distances = model.nearest(selected["features"], all_data[others])
    st.write("**Los cinco animales más similares en sus 20 rasgos**")
    st.dataframe(pd.DataFrame([{"Animal": f"{animals[others[i]]['emoji']} {animals[others[i]]['name']}",
                              "Distancia normalizada": round(float(d), 4)} for i, d in zip(indices, distances)]), hide_index=True, width="stretch")
    st.caption("Distancia 0 significa igualdad de rasgos en este dataset. La similitud no implica parentesco biológico.")

st.subheader("Datos y explicación")
dataset_tab, dictionary_tab, learning_tab, explanation_tab = st.tabs(["Dataset completo", "Escalas de características", "Aprendizaje", "Del PHP a Python"])
with dataset_tab:
    readable = st.checkbox("Mostrar categorías en lugar de números", True)
    st.dataframe(records(animals, readable), hide_index=True, width="stretch")
    st.download_button("Descargar dataset CSV", records(animals).to_csv(index=False).encode("utf-8-sig"), "dataset_animales.csv", "text/csv")
with dictionary_tab:
    st.dataframe(pd.DataFrame(feature_dictionary()), hide_index=True, width="stretch")
    st.caption("Se utilizan escalas de 2, 3, 4 y 5 opciones. Las categorías son simplificaciones para adultos y sus valores son decisiones didácticas aproximadas. Consulta docs/DATASET.md para los criterios y fuentes.")
with learning_tab:
    history = pd.DataFrame(model.history)
    chart = px.line(history, x="Época", y="Error de cuantización", markers=True)
    chart.update_traces(line_color="#0b9163")
    st.plotly_chart(chart, width="stretch", key="learning_chart")
    st.write(f"Error topográfico final: **{model.topographic_error(training_data):.2%}**. Es la proporción de animales cuyas dos mejores neuronas no comparten una cara en el grid 3D.")
    st.caption("El error puede subir en alguna época; el SOM no garantiza una reducción monótona. Las métricas corresponden al conjunto usado en el entrenamiento.")
    st.download_button("Descargar configuración y métricas", json.dumps({"config": asdict(config),
        "training_animals": len(training_data), "include_custom": st.session_state.include_custom,
        "quantization_error": model.quantization_error(training_data),
        "topographic_error": model.topographic_error(training_data), "history": model.history}, indent=2),
        "entrenamiento_som.json", "application/json")
with explanation_tab:
    st.write("El archivo som_comentado.php genera una página y selectores. Su JavaScript inicializa pesos, suma diferencias absolutas para elegir una BMU y actualiza vecinos con una gaussiana. En Python, features.py define los selectores, som.py ejecuta el algoritmo y app.py coordina la interacción con Streamlit.")
    st.latex(r"b = \arg\min_j\, d(x,W_j)")
    st.latex(r"W_j \leftarrow W_j + \alpha(t)\,\exp\!\left(-\frac{\|r_j-r_b\|^2}{2\sigma(t)^2}\right)(x-W_j)")
    st.write("r contiene tres coordenadas de retícula; W contiene los 20 pesos. La tasa de aprendizaje y el radio disminuyen a lo largo de las épocas. Los pesos se inicializan entre 0 y 1, y el orden de animales se baraja de forma reproducible.")
    st.write("La adaptación acepta distancias cero, añade una tasa explícita, recalcula las posiciones al terminar y completa la barra de progreso al 100 %. Los animales nuevos se ubican sin alterar el modelo, salvo que actives su inclusión en el entrenamiento.")
