"""Genera un único HTML ejecutable, sin carpetas ni archivos de apoyo."""
import json
from dataclasses import asdict
from pathlib import Path
from features import FEATURES, ECOSYSTEMS, EMOJIS
from dataset import load_base
from som import SOM3D, SOMConfig
from browser_backend import BrowserSession

ROOT = Path(__file__).parent

def build():
    base = load_base()
    model = SOM3D().train([a['features'] for a in base])
    initial = {'base': base, 'config': asdict(model.config),
               'weights': model.weights.tolist(), 'history': model.history}
    snapshot = BrowserSession(initial).snapshot()
    modules = ['features.py', 'animal_validation.py', 'som.py', 'browser_backend.py']
    embedded = {'initial': initial, 'snapshot': snapshot,
                'features': [{**asdict(f), 'scale': f.scale} for f in FEATURES],
                'ecosystems': ECOSYSTEMS, 'emojis': EMOJIS,
                'sources': {name: (ROOT / name).read_text() for name in modules}}
    html = (ROOT / 'web/template.html').read_text()
    html = html.replace('/*__CSS__*/', (ROOT / 'web/style.css').read_text())
    html = html.replace('/*__DATA__*/', json.dumps(embedded, ensure_ascii=False).replace('<', r'\u003c'))
    html = html.replace('/*__JS__*/', (ROOT / 'web/app.js').read_text())
    (ROOT / 'index.html').write_text(html, encoding='utf-8')
    # Sustituye la antigua vista parcial por la aplicación completa.
    (ROOT / 'artifacts/mapa_som_3d.html').write_text(html, encoding='utf-8')
    (ROOT / '.nojekyll').touch()
    print(f'index.html: {len(html.encode()):,} bytes; {len(base)} animales, Python real en navegador.')
    return initial

if __name__ == '__main__':
    build()
