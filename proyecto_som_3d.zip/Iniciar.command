#!/bin/zsh
# Inicia la aplicación desde su propia carpeta, aunque se abra con doble clic.
cd "${0:A:h}" || exit 1

task_python=""
# Reutiliza el entorno local o la instalación de Anaconda disponible en este Mac.
for candidate in "$PWD/.venv/bin/python" /opt/anaconda3/bin/python python3.14 python3.13 python3.12 python3; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; assert sys.version_info >= (3, 12)' >/dev/null 2>&1; then
        task_python="$candidate"
        break
    fi
done
if [[ -z "$task_python" ]]; then
    print "Se necesita Python 3.12 o posterior. Consulta README.md para instalarlo."
    read "?Pulsa Enter para cerrar."
    exit 1
fi

# La instalación se hace únicamente si no están disponibles las versiones del proyecto.
if ! "$task_python" -c 'from importlib.metadata import version; assert all(version(k) == v for k, v in {"streamlit":"1.58.0", "numpy":"2.4.6", "pandas":"3.0.3", "plotly":"6.7.0"}.items())' >/dev/null 2>&1; then
    print "Preparando un entorno aislado. La primera instalación necesita internet."
    "$task_python" -m venv .venv || exit 1
    task_python="$PWD/.venv/bin/python"
    "$task_python" -m pip install -r requirements.txt || {
        print "No se pudieron instalar las dependencias. Consulta README.md."
        read "?Pulsa Enter para cerrar."
        exit 1
    }
fi
print "Abre http://localhost:8501 en tu navegador. Mantén esta ventana abierta."
exec "$task_python" -m streamlit run app.py --server.fileWatcherType none
