"""Empaqueta la entrega y los dos archivos necesarios para GitHub Pages."""
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).parent
files=['index.html','.nojekyll','README.md','animal_validation.py','browser_backend.py',
       'build_web.py','package_project.py','app.py','som.py','features.py','dataset.py',
       'visualization.py','export_result.py','requirements.txt','requirements-dev.txt',
       'Iniciar.command','.gitignore','.streamlit/config.toml']
for directory in ('web','docs','tests','data','artifacts'):
    files += [str(p.relative_to(ROOT)) for p in (ROOT/directory).rglob('*')
              if p.is_file() and '__pycache__' not in str(p) and p.suffix!='.pyc'
              and p.name!='proyecto.json']
# La copia distribuible no incluye la captura ni el documento original personal.
metadata={'titulo':'Mapa autoorganizado 3D de animales','materia':'','docente':'','integrantes':[]}
with ZipFile(ROOT/'proyecto_som_3d.zip','w',ZIP_DEFLATED) as archive:
    for name in sorted(set(files)):
        archive.write(ROOT/name,name)
    archive.writestr('data/proyecto.json',json.dumps(metadata,ensure_ascii=False,indent=2))
with ZipFile(ROOT/'publicar_github_pages.zip','w',ZIP_DEFLATED) as archive:
    for name in ('index.html','.nojekyll'):
        archive.write(ROOT/name,name)
print('Entrega completa y paquete mínimo de publicación actualizados.')
