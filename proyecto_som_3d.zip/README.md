# Atlas animal · Mapa autoorganizado 3D

**[Abre la aplicación publicada](https://zoecrz.github.io/atlas-animal-som-3d/)** o abre [index.html](index.html) en Chrome, Edge o Firefox actualizado, con internet. Ese único archivo contiene la aplicación: mapa 3D, búsqueda, filtros, fichas, entrenamiento y formulario para agregar animales. Puedes compartir solo ese HTML; no requiere instalar Python ni iniciar un servidor.

Espera a que aparezca **“Listo para explorar y entrenar”**. La primera carga descarga Python y NumPy desde el CDN de Pyodide y puede tardar. El mapa inicial aparece inmediatamente. Sin internet puedes explorar ese resultado, pero no se garantiza entrenar ni agregar animales: el runtime es una dependencia externa.

## Qué puedes hacer

1. Arrastra el mapa para girarlo y usa la rueda o los botones ＋ y − para acercarte. Selecciona un emoji o un animal del catálogo.
2. Busca por nombre o filtra por ecosistema. La ficha muestra X, Y, Z, los animales que comparten posición, tres parecidos y los 20 rasgos.
3. Pulsa **Ajustar mapa** para cambiar épocas, tamaño del cubo, tasa, radio, semilla y distancia. Pulsa **Entrenar mapa** para aplicar los cambios.
4. Pulsa **Agregar animal**. Completa el nombre, ecosistema, un emoji animal disponible y los 20 rasgos de los cuatro grupos.
5. Usa **Guardar mis animales** para descargar un JSON e **Importar** para recuperarlos en otro navegador. Importar reemplaza los animales agregados, conservando los 45 animales base.

Los animales agregados se guardan automáticamente en el navegador cuando este permite almacenamiento local. El HTML compartido conserva los 45 animales base: compartir el archivo no transmite tus animales guardados. Para compartirlos, adjunta su JSON. El entrenamiento modificado no se guarda al cerrar o recargar; la página recupera los animales y los ubica sobre el modelo inicial.

Si activas **Incluir mis animales en el aprendizaje**, agregar o importar vuelve a entrenar con el conjunto ampliado. Sin esa opción, los animales nuevos se proyectan sobre los pesos actuales. **Volver al mapa inicial** elimina los agregados del navegador y restaura los parámetros predeterminados; **Restablecer vista** solo cambia la cámara.

## Emojis y datos

Hay **45 animales, 45 emojis animales diferentes, 20 rasgos y 10 ecosistemas**. No se usan huellas, alimentos u objetos para representar especies. Se adaptó la selección de especies a los emojis disponibles; por ejemplo, el ajolote fue sustituido por un pez globo con 🐡. Cada animal mantiene su emoji en el catálogo, su ficha y al seleccionarlo en el mapa. Un nodo compartido muestra un representante y un contador; la ficha permite seleccionar cualquiera de sus miembros.

Los emojis son Unicode nativo: iOS usa su propia apariencia y otros sistemas usan la suya. Los datos son categorías educativas aproximadas. El mapa compara rasgos y no demuestra parentesco ni exactitud de clasificación.

## Publicación para obtener un solo enlace

La aplicación está preparada para **GitHub Pages**, que puede publicar el archivo `index.html` directamente. El repositorio público [ZoeCrz/atlas-animal-som-3d](https://github.com/ZoeCrz/atlas-animal-som-3d) ya está creado y GitHub Pages completó el despliegue. Comparte **[este enlace a la aplicación](https://zoecrz.github.io/atlas-animal-som-3d/)**. Consulta [docs/PUBLICACION.md](docs/PUBLICACION.md).

No hace falta Streamlit Cloud para publicar esta versión. [GitHub Pages admite un archivo `index.html` como entrada de un sitio estático](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site). La página ejecuta el cálculo en el navegador del visitante.

## Python y versión Streamlit

El algoritmo, la validación, el entrenamiento y las posiciones se implementan en Python. La versión HTML ejecuta los mismos módulos `som.py`, `features.py`, `animal_validation.py` y `browser_backend.py` mediante **Pyodide 314.0.7** en un Web Worker. JavaScript gestiona la interfaz y dibuja una proyección del cubo 3D; no reemplaza el algoritmo de Kohonen.

El documento original pedía Streamlit como herramienta principal. A partir de la petición posterior de compartir un único HTML ejecutable, esta entrega prioriza la versión de navegador. Se conserva la aplicación Python/Streamlit en `app.py` como alternativa para la evaluación o el desarrollo local. [Pyodide permite ejecutar Python y cargar paquetes en un navegador](https://pyodide.org/en/stable/usage/quickstart.html); [el Web Worker mantiene el cálculo separado de la interfaz](https://pyodide.org/en/stable/usage/webworker.html).

Para abrir Streamlit en este Mac, haz doble clic en [Iniciar.command](Iniciar.command). En otro equipo con Python 3.12 o posterior:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

En Windows activa el entorno con `.venv\Scripts\activate`. El entorno de este Mac `/opt/anaconda3/bin/python` ya contiene las dependencias.

## Desarrollo y validación

- `web/`: fuentes HTML, CSS y JavaScript de la interfaz.
- `build_web.py`: integra interfaz, dataset, resultado inicial y módulos Python en un único `index.html` de aproximadamente 145 KB. El runtime se descarga aparte al abrirlo.
- `export_result.py`: regenera el HTML y la evidencia CSV/JSON de `artifacts/`. `artifacts/mapa_som_3d.html` es una copia completa de la nueva aplicación.
- [docs/IMPLEMENTACION.md](docs/IMPLEMENTACION.md): algoritmo y correspondencia con PHP.
- [docs/DATASET.md](docs/DATASET.md): escalas, criterios y fuentes.
- [docs/DEMOSTRACION.md](docs/DEMOSTRACION.md): recorrido para presentarlo.

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python export_result.py
```

Se verificaron **47 pruebas automatizadas**, la carga de Python en Chrome desde el archivo local, el entrenamiento de un cubo 3 × 3 × 3 y el alta de un animal con 20 rasgos. Con el dataset actual, semilla 42 y 80 épocas, el error de cuantización de referencia baja de **0.2776 a 0.0570** y se ocupan **29 de 125 nodos**. Los valores pueden variar ligeramente entre entornos numéricos.

Si el motor no carga, revisa internet y pulsa **Reintentar**. Si el navegador bloquea el CDN, abre la URL publicada o prueba otro navegador actualizado. El despliegue inicial se completó con éxito: en la URL pública cargó Python y se verificó un entrenamiento de 10 épocas con un cubo de lado 3.
