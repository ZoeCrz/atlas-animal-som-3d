"""Regenera evidencia del entrenamiento y la aplicación ejecutable de un HTML."""
import json
from dataclasses import asdict
from pathlib import Path
import numpy as np
import pandas as pd
from dataset import load_base, matrix
from features import FEATURES
from som import SOM3D
from visualization import positions_table
from build_web import build

def main():
    folder=Path(__file__).parent/'artifacts'
    folder.mkdir(exist_ok=True)
    animals=load_base();data=matrix(animals);model=SOM3D().train(data)
    coordinates=model.map(data)
    metrics={'config':asdict(model.config),'animals':len(animals),'features':len(FEATURES),
             'neurons':len(model.coordinates),'occupied_nodes':len(np.unique(coordinates,axis=0)),
             'initial_quantization_error':model.history[0]['Error de cuantización'],
             'final_quantization_error':model.quantization_error(data),
             'topographic_error':model.topographic_error(data),'history':model.history}
    (folder/'metricas.json').write_text(json.dumps(metrics,indent=2,ensure_ascii=False)+'\n')
    positions_table(animals,coordinates).to_csv(folder/'posiciones_som_3d.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(model.history).to_csv(folder/'aprendizaje.csv',index=False,encoding='utf-8-sig')
    build()
    print(json.dumps({k:v for k,v in metrics.items() if k!='history'},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
