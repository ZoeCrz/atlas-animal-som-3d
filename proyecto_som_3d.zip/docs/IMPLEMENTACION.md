# Implementación del mapa autoorganizado 3D

El proyecto convierte cada animal en un vector de 20 rasgos entre 0 y 1. Un SOM de Kohonen aprende prototipos en una retícula cúbica y asigna cada animal al prototipo más parecido. La posición resultante tiene tres coordenadas discretas X, Y y Z. La versión HTML presenta una introducción, el mapa a la izquierda, el catálogo a la derecha y una ficha debajo. El formulario y los parámetros se abren en ventanas separadas. Streamlit se conserva como versión local alternativa.

## Correspondencia con el archivo original

Aunque el archivo se llama `som_comentado.php`, PHP genera principalmente el HTML y algunos selectores; el entrenamiento está implementado en JavaScript.

| Elemento original | Implementación Python | Cambio |
| --- | --- | --- |
| `$etiquetas` y `etiquetas` | `FEATURES` en `features.py` | 20 definiciones compartidas por formulario, validación y datos |
| `Animales` y `Caract` | `data/animales.json`, `dataset.matrix` | 45 animales diferentes a los 20 originales |
| `R` | `SOMConfig.epochs` | Épocas desde la interfaz |
| `FC` | `SOMConfig.grid_size` | Lado del cubo; ahora hay FC³ neuronas |
| `N` | Segunda dimensión de la matriz | 20 pesos por neurona |
| `W` plano | `SOM3D.weights` | Matriz con forma `(lado³, 20)` |
| `DS` | `SOMConfig.sigma` | Radio configurable y decreciente |
| Bucles para obtener mínimo | `_distances` y `argmin` | Selección vectorizada de la BMU |
| `AW` | Actualización vectorizada de pesos | Incluye tasa de aprendizaje explícita |
| `PosMn` | `model.map` | Coordenadas finales `(animales, 3)` |
| `cargar_nuevo` | `animal_validation.py`, `browser_backend.py` y formulario web | Nombre, emoji, ecosistema y 20 rasgos |
| Canvas 2D | Cubo real calculado en Python; Canvas y botones emoji en el navegador | Rotación, zoom, retícula, nodos compartidos y filtros |
| `resetear` | Limpiar formulario | Se diferencia de restaurar los animales base |

## Algoritmo

1. Se valida la matriz y se inicializan pesos aleatorios uniformes entre 0 y 1.
2. Se crean todas las coordenadas `(x, y, z)` con cada eje desde 0 hasta `lado − 1`.
3. En cada época se baraja el orden de los animales, usando la semilla seleccionada.
4. Para cada animal se elige la BMU `b = argmin_j d(entrada, W_j)`.
5. Se calcula la distancia geométrica entre cada neurona y la BMU dentro del cubo.
6. Se actualizan sus 20 pesos con la regla de Kohonen.
7. Se recalculan las posiciones de todos los animales usando los pesos finales.

La regla de aprendizaje es:

```text
h(j, b, t) = exp(−distancia_grid(j, b)² / (2 × sigma(t)²))
W_j = W_j + alpha(t) × h(j, b, t) × (entrada − W_j)
alpha(t) = alpha_inicial × 0.1^fraccion
sigma(t) = sigma_inicial × (0.5 / sigma_inicial)^fraccion
fraccion = época_desde_cero / max(épocas − 1, 1)
```

La distancia de entrada puede ser Manhattan, `suma(abs(entrada − W_j))`, o euclidiana, `raíz(suma((entrada − W_j)²))`. La distancia para la vecindad gaussiana siempre es geométrica euclidiana en la retícula. Son dos distancias con propósitos diferentes.

El valor predeterminado es Manhattan porque el JavaScript original suma diferencias absolutas, pese a que uno de sus comentarios la llama euclidiana. La adaptación elimina la condición que descartaba distancias exactamente 0 y 1. Una coincidencia exacta debe poder ganar. También evita guardar posiciones anteriores a la última actualización y elimina el desplazamiento aleatorio del dibujo original.

No se añade un eje Z decorativo ni se aplica PCA después de un SOM bidimensional: **la topología de aprendizaje es cúbica**, con vecindad en los tres ejes. Esta elección satisface la representación tridimensional requerida mediante una asignación desde 20 rasgos a tres índices de retícula. Las coordenadas son discretas y no representan componentes principales.

## Controles de entrenamiento

| Control | Predeterminado | Intervalo de la interfaz | Interpretación |
| --- | --- | --- | --- |
| Épocas | 80 | 10 a 300 | Veces que se procesa el conjunto completo |
| Lado del grid | 5 | 2 a 10 | 8 a 1000 neuronas en una retícula cúbica |
| Tasa inicial | 0.50 | 0.05 a 1.00 | Intensidad de actualización; termina en una décima parte |
| Radio inicial | 2.0 | 0.5 a 10.0 | Alcance de la gaussiana; termina en 0.5 |
| Semilla | 42 | 0 a 4294967295 | Reproduce la inicialización y el orden de muestras |
| Distancia | Manhattan | Manhattan o euclidiana | Comparación entre vector y prototipo |

La opción adicional para incluir animales agregados determina qué registros participan en el aprendizaje. Sin ella, los nuevos animales se ubican con `map` y no modifican los pesos. Si se activa, agregar o importar cambia los datos de entrenamiento y se recalcula el mapa con la configuración aplicada. Filtrar, buscar, cambiar de pestaña o consultar otro animal conserva los pesos.

La semilla produce resultados reproducibles dentro del mismo entorno y dataset. Diferentes versiones de librerías o pequeñas diferencias numéricas entre plataformas pueden alterar empates; `requirements.txt` fija las versiones usadas.

## Métricas y resultados

El error de cuantización es la distancia promedio entre cada animal y su BMU. Manhattan se divide entre el número de características; euclidiana se divide entre la raíz del número de características. Así ambas métricas quedan entre 0 y 1 para estos datos. Al cambiar la distancia, cambia el criterio del error; no debe tratarse como una comparación idéntica entre métricas.

El error topográfico mide la fracción de animales cuyas dos neuronas más cercanas no son vecinas de cara. Se usa una vecindad de seis caras: deben diferir exactamente una unidad en un solo eje. No incluye contactos por aristas o vértices.

| Resultado predeterminado | Valor |
| --- | --- |
| Animales de entrenamiento | 45 |
| Rasgos | 20 |
| Retícula | 5 × 5 × 5 |
| Pesos totales | 125 × 20 = 2500 |
| Épocas | 80 |
| Error inicial | 0.27758980 |
| Error final | 0.05700373 |
| Error topográfico | 4.44 % |
| Nodos ocupados | 29 |

Los valores detallados están en `artifacts/metricas.json`. Un mismo nodo puede contener varios animales; esto expresa una asignación compartida, no un error de visualización. No se inventan coordenadas ni se mueven puntos para separarlos. El mapa muestra un representante y un contador. La ficha permite seleccionar todos los miembros y consultar sus coordenadas.

El SOM es aprendizaje no supervisado. No predice una clase con una exactitud medible aquí, ni garantiza parentesco entre especies. La lista de cinco animales similares utiliza distancias en los 20 rasgos originales, no distancias en pantalla. Las etiquetas por ecosistema son información de consulta y no etiquetas de entrenamiento.

## Revisión de requisitos

| Requisito del documento | Evidencia | Estado |
| --- | --- | --- |
| 45 animales totalmente nuevos | JSON, CSV y prueba contra los nombres originales | Implementado |
| Múltiples ecosistemas | 10 categorías de referencia | Implementado |
| 20 rasgos nuevos o renombrados | `FEATURES`, diccionario de escalas y formulario | Implementado |
| Escalas de 3, 4 y 5 opciones | Todos los niveles aparecen en el dataset | Implementado |
| Tres variables X, Y, Z | SOM cúbico, tabla y gráfico 3D | Implementado |
| Visualización interactiva opcional | Rotación, zoom, filtros y hover | Implementado |
| Al menos tres hiperparámetros | Seis controles de entrenamiento | Implementado |
| Agregar nombre, rasgos y emoji | Formulario con validación y persistencia de sesión | Implementado |
| Emojis visibles entre plataformas | Unicode en formulario, tablas y hover | Implementado con apariencia propia del dispositivo |
| Usar Python y Streamlit | Python compartido; `app.py` conserva Streamlit. El HTML es principal por la petición posterior | Implementado con ajuste de entrega solicitado |
| Distribución comprensible | Introducción, mapa izquierdo, catálogo derecho, ficha y formularios separados | Rediseñado según la petición posterior |
| Código comentado y README | Módulos comentados, README y guías | Implementado |
| Archivos dentro de la carpeta | Todo el proyecto y sus resultados son locales | Implementado |
| Acceso desde un enlace público | [Atlas animal](https://zoecrz.github.io/atlas-animal-som-3d/) en GitHub Pages | Publicado |

## Python dentro del HTML

`build_web.py` integra las fuentes, las escalas, los datos base y un modelo inicial en `index.html`. Un Worker de módulo carga Pyodide 314.0.7 y NumPy desde su CDN. En archivos `file://` se usa una URL `data:` para el Worker, compatible con la política de orígenes de Chrome; no se desactivan protecciones del navegador.

`BrowserSession` ejecuta validación, entrenamiento, BMU y vecinos en Python. Cada operación valida sus entradas antes de sustituir el estado. La interfaz utiliza los resultados calculados por Python, dibuja el cubo mediante una rotación ortográfica y coloca botones emoji en sus coordenadas proyectadas. No mueve los animales dentro de la retícula para evitar solapamientos.

El almacenamiento local conserva únicamente los animales agregados. Al recargar, estos se validan y se proyectan sobre el modelo inicial. La importación JSON permite transportarlos entre navegadores. El entrenamiento opera sin servidor una vez cargado el runtime; cargarlo necesita internet. El HTML no contiene el runtime completo ni garantiza ejecución sin conexión.

## Validación y límites de la comprobación

Se ejecutaron 47 pruebas con pytest: algoritmo, dataset, flujos de Streamlit y ocho comprobaciones del motor web, incluidas operaciones atómicas, importación, entrenamiento, coincidencias exactas y proyección de nuevos animales.

Se verificó en Chrome que el HTML local carga Python y NumPy, permite entrenar con 10 épocas y un cubo de lado 3, y permite agregar un oso con un emoji propio y 20 rasgos. Se revisaron visualmente la introducción, mapa, catálogo, ficha y formularios. GitHub Pages completó correctamente la publicación. En [su URL real](https://zoecrz.github.io/atlas-animal-som-3d/) cargó Python y se verificó el entrenamiento de 10 épocas en un cubo de lado 3.

## Referencias técnicas

- [Formularios en Streamlit](https://docs.streamlit.io/develop/api-reference/execution-flow/st.form): procesamiento conjunto del formulario al enviarlo.
- [Scatter3d en Plotly](https://plotly.com/python-api-reference/generated/plotly.graph_objects.Scatter3d.html): gráfico de puntos con coordenadas X, Y y Z.
- [Despliegue en Streamlit Community Cloud](https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy): selección de repositorio, archivo principal y publicación.

- [Pyodide en un Web Worker](https://pyodide.org/en/stable/usage/webworker.html): ejecución de Python sin bloquear la interfaz.
- [GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site): publicación del HTML estático.
