# Recorrido de cinco minutos

Abre `index.html` con internet y espera “Listo para explorar y entrenar”. No necesitas Terminal ni Streamlit para demostrar la versión principal.

## 1. Presentar la idea

“Este mapa compara 45 animales a partir de 20 características. Python aprende prototipos en una retícula de tres dimensiones y asigna cada animal al más parecido. Los ecosistemas sirven para explorar, pero no determinan la posición.”

## 2. Explorar y comparar

Gira el mapa arrastrando, acerca con la rueda y selecciona un emoji. Consulta su nombre, ecosistema, coordenadas y tres parecidos. Abre “Ver sus 20 características”. Un contador indica un nodo compartido; la ficha permite elegir todos sus miembros.

Busca “Reno” y después “Bisonte”. Con la configuración inicial ambos comparten `(0, 4, 4)`. Sus emojis son diferentes. Filtra “Océano” para mostrar los animales marinos y después vuelve a todos los ecosistemas. Buscar y filtrar conservan el modelo.

## 3. Agregar un animal

Pulsa “Agregar animal” y registra **Oso pardo**, emoji **🐻**, ecosistema **Bosque templado**. Las siguientes opciones son una propuesta educativa para demostrar el formulario; no son mediciones científicas.

| Rasgo | Opción |
| --- | --- |
| Longitud corporal | 1 a menos de 3 m |
| Masa corporal | 100 kg o más |
| Longevidad potencial | 15 a menos de 40 años |
| Patas locomotoras | Cuatro |
| Dependencia acuática | Agua ocasional |
| Capacidad de vuelo | No vuela |
| Capacidad de trepar | Ocasional |
| Movilidad terrestre | Alta |
| Capacidad de nadar | Alta |
| Componente vegetal de dieta | Mixto |
| Especialización alimentaria | Generalista |
| Vida en grupo | Solitario |
| Actividad nocturna | Mixto o crepuscular |
| Adaptación al frío | Alta |
| Dependencia de humedad | Moderada |
| Endotermia predominante | Sí |
| Columna vertebral | Sí |
| Puesta de huevos | No |
| Presencia de pelaje | Sí |
| Presencia de plumaje | No |

Completa los cuatro grupos y pulsa “Agregar y ubicar”. El contador sube a 46 y aparece la ficha del oso. Si ya agregaste ese animal, usa la ficha existente o restaura el mapa antes de repetir el ejemplo: nombres y emojis deben ser únicos.

Para una demostración rápida también puedes importar `artifacts/ejemplo_oso_pardo.json`, que contiene exactamente estas opciones. Importar reemplaza tus agregados.

Usa “Guardar mis animales” para descargar el JSON. El navegador guarda los agregados, pero el JSON permite llevarlos a otro equipo.

## 4. Experimentar con el entrenamiento

En “Ajustar mapa”, usa 10 épocas y tamaño 3. Entrena y observa nuevas coordenadas entre 0 y 2: ahora hay 27 neuronas. La tasa cambia la intensidad del aprendizaje; el radio cambia su alcance. Una semilla permite repetir el resultado en el mismo entorno.

Sin “Incluir mis animales en el aprendizaje”, el oso solo se proyecta sobre los prototipos entrenados con los 45 animales base. Con esa opción, participa al entrenar. “Volver al mapa inicial” elimina agregados y recupera 5 × 5 × 5, 80 épocas, tasa 0.5, radio 2, semilla 42 y Manhattan.

## 5. Explicar la entrega

El HTML contiene los datos, la interfaz y los módulos Python. Pyodide descarga el runtime y ejecuta Python en el navegador; JavaScript dibuja la proyección 3D y maneja los controles. `som.py` contiene la elección de la BMU y la actualización de Kohonen. `app.py` conserva la alternativa Streamlit del requerimiento original.

Para compartir basta enviar `index.html` o el enlace publicado: [abrir Atlas animal](https://zoecrz.github.io/atlas-animal-som-3d/). El repositorio está en [GitHub](https://github.com/ZoeCrz/atlas-animal-som-3d). `docs/PUBLICACION.md` explica cómo actualizar el sitio.
