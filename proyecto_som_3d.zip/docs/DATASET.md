# Dataset y criterios de codificación

El conjunto contiene 45 especies y 20 características por animal. Los nombres son diferentes a los animales del archivo original. Hay mamíferos, aves, reptiles, anfibios, peces e invertebrados de ambientes terrestres, acuáticos, polares y tropicales.

## Alcance de los valores

Los valores son **categorías educativas propuestas** para un adulto representativo. No son mediciones recogidas mediante un estudio ni una base zoológica validada de los 45 animales. Sirven para estudiar el SOM y discutir cómo la codificación afecta la similitud. Los rasgos físicos se agrupan por intervalos; las capacidades y conductas se asignan de forma orientativa. Sexo, edad, población, estación y cautiverio pueden cambiar la categoría adecuada.

Se revisaron fichas representativas de Animal Diversity Web para el lobo gris, pingüino emperador, pulpo común, mariposa monarca, ardilla voladora y tarántula del desierto. Esta consulta no equivale a verificar individualmente los 900 valores del dataset. Las escalas y puntuaciones son decisiones del proyecto, no puntuaciones publicadas por esas fuentes.

Los datos de referencia se guardan en `data/build_dataset.py` como índices de categorías. El script transforma los índices a valores normalizados y genera `data/animales.json` y `data/animales.csv`. El orden de las columnas está definido exclusivamente por `FEATURES` en `features.py`.

## Escalas

| Cantidad de opciones | Valores normalizados |
| --- | --- |
| 2 | 0, 1 |
| 3 | 0, 0.5, 1 |
| 4 | 0, 0.33, 0.66, 1 |
| 5 | 0, 0.25, 0.5, 0.75, 1 |

La escala de cuatro opciones conserva literalmente 0.33 y 0.66 como pide el documento. No los reemplaza silenciosamente por 1/3 y 2/3. Todos los niveles de cada característica aparecen al menos una vez en el dataset base; esta condición se verifica con una prueba.

Se usan 9 rasgos de cinco opciones, 3 rasgos de tres opciones, 3 rasgos de cuatro opciones y 5 rasgos binarios, para un total de 20 rasgos.

## Diccionario de las 20 características

| Rasgo | Escala y categorías | Criterio |
| --- | --- | --- |
| Longitud corporal | 0 = Menos de 10 cm; 0.25 = 10 a menos de 40 cm; 0.5 = 40 a menos de 100 cm; 0.75 = 1 a menos de 3 m; 1 = 3 m o más | Longitud aproximada del adulto, sin envergadura. Los límites inferiores están incluidos. |
| Masa corporal | 0 = Menos de 0.1 kg; 0.25 = 0.1 a menos de 1 kg; 0.5 = 1 a menos de 10 kg; 0.75 = 10 a menos de 100 kg; 1 = 100 kg o más | Masa representativa del adulto; no describe todos los sexos y poblaciones. |
| Longevidad potencial | 0 = Menos de 1 año; 0.25 = 1 a menos de 5 años; 0.5 = 5 a menos de 15 años; 0.75 = 15 a menos de 40 años; 1 = 40 años o más | Categoría orientativa de longevidad potencial, no esperanza de vida promedio. |
| Patas locomotoras | 0 = Sin patas; 0.25 = Dos; 0.5 = Cuatro; 0.75 = Seis; 1 = Ocho o más | No se cuentan brazos de pulpos ni aletas. Es una escala ordinal de cantidad, no de velocidad. |
| Dependencia acuática | 0 = Terrestre; 0.25 = Agua ocasional; 0.5 = Semiacuático; 0.75 = Mayormente acuático; 1 = Totalmente acuático | Desde vida terrestre hasta vida permanentemente en el agua. |
| Capacidad de vuelo | 0 = No vuela; 0.5 = Planea; 1 = Vuelo activo | El planeo se diferencia del vuelo propulsado. |
| Capacidad de trepar | 0 = No trepa; 0.5 = Ocasional; 1 = Habitual | Capacidad funcional para desplazarse por árboles o superficies verticales. |
| Movilidad terrestre | 0 = Nula; 0.25 = Muy baja; 0.5 = Baja; 0.75 = Moderada; 1 = Alta | Capacidad relativa en tierra; no equivale a una velocidad medida en km/h. |
| Capacidad de nadar | 0 = Nula; 0.25 = Limitada; 0.5 = Moderada; 0.75 = Alta; 1 = Especializada | Capacidad relativa de desplazarse en el agua. |
| Componente vegetal de dieta | 0 = Nulo o mínimo; 0.25 = Bajo; 0.5 = Mixto; 0.75 = Predominante; 1 = Casi exclusivo | Fracción aproximada de alimento de origen vegetal. Evita ordenar artificialmente etiquetas como carnívoro e insectívoro. |
| Especialización alimentaria | 0 = Generalista; 0.33 = Preferencias leves; 0.66 = Dieta restringida; 1 = Muy especializado | Escala didáctica desde dieta amplia hasta dependencia de pocos alimentos. |
| Vida en grupo | 0 = Solitario; 0.33 = Parejas o encuentros; 0.66 = Grupos pequeños; 1 = Colonias o grupos grandes | Patrón típico simplificado; puede cambiar durante reproducción o migración. |
| Actividad nocturna | 0 = Principalmente diurno; 0.5 = Mixto o crepuscular; 1 = Principalmente nocturno | Patrón de actividad predominante del adulto. |
| Adaptación al frío | 0 = Muy baja; 0.25 = Baja; 0.5 = Moderada; 0.75 = Alta; 1 = Polar | Adaptación ecológica aproximada; no es una temperatura mínima medida. |
| Dependencia de humedad | 0 = Baja; 0.33 = Moderada; 0.66 = Alta; 1 = Agua o humedad constante | Desde ambientes secos hasta necesidad permanente de agua o humedad. |
| Endotermia predominante | 0 = No; 1 = Sí | Producción interna de calor predominante: mamíferos y aves. Se simplifican casos especiales. |
| Columna vertebral | 0 = No; 1 = Sí | Distingue vertebrados e invertebrados. |
| Puesta de huevos | 0 = No; 1 = Sí | La especie pone huevos; no se confunde con desarrollo interno de huevos. |
| Presencia de pelaje | 0 = No; 1 = Sí | Pelaje de mamíferos; no se cuentan pelos aislados de cetáceos ni setas de artrópodos. |
| Presencia de plumaje | 0 = No; 1 = Sí | Plumas presentes en el adulto, incluso aves que no vuelan. |

## Distribución de los animales

| Ecosistema de referencia | Cantidad |
| --- | --- |
| Bosque templado | 5 |
| Ártico | 3 |
| Pradera | 3 |
| Desierto | 2 |
| Agua dulce | 5 |
| Costa | 3 |
| Antártico | 1 |
| Océano | 10 |
| Selva tropical | 10 |
| Aéreo | 3 |
| **Total** | **45** |

Los 45 nombres, nombres científicos y los 900 valores pueden consultarse en `data/animales.csv` y cada animal puede consultarse en la ficha de la aplicación.

## Cómo interpretar las decisiones

**Escalas ordenadas.** La dependencia acuática, el componente vegetal de la dieta y las capacidades tienen un orden explícito. Se evita convertir categorías nominales de dieta o ecosistema en números que implicarían una cercanía arbitraria. “Componente vegetal” significa alimento de origen vegetal y comprende frutos, semillas, hojas y néctar; en la hormiga cortadora se considera el alimento de origen vegetal transformado mediante su cultivo de hongos.

**Rasgos físicos.** La longitud describe el cuerpo y puede incluir la cola de acuerdo con la morfología; excluye envergadura, extensión de tentáculos y separación de patas. La masa representa un adulto típico, y la longevidad es una categoría de potencial de vida. En insectos sociales se usa un adulto obrero para la longevidad; una reina puede vivir mucho más.

**Número de patas.** Se cuentan estructuras usadas funcionalmente como patas. Aletas y brazos de pulpos no se convierten en patas. En canguros se cuenta el apoyo bípedo de la locomoción predominante; en murciélagos se cuentan las dos extremidades posteriores, porque las anteriores son alas. La codificación es ordinal: las cinco categorías no expresan intervalos iguales de cantidad ni implican que tener más patas aumente la movilidad.

**Pelaje y plumaje.** Pelaje se reserva para mamíferos con cobertura apreciable. Las setas de una tarántula no se codifican como pelaje de mamífero. Las aves no voladoras conservan plumaje. Las pequeñas cantidades de pelo de cetáceos no se consideran pelaje.

**Especialización.** El rasgo describe amplitud de dieta; no distingue especies depredadoras por sí mismo. La especialización alimentaria, socialidad, adaptación al frío y humedad son puntuaciones cualitativas del proyecto.

**Ecosistema de referencia.** Es una etiqueta de presentación: una especie puede ocupar muchos ambientes. “Aéreo” agrupa animales por locomoción y no es un ecosistema biológico separado. No se usa este campo para entrenar; la etiqueta permite filtrar y consultar el mapa. El ecosistema que el usuario elija tampoco cambia la posición si los veinte rasgos se mantienen iguales.

**Emojis.** Se usan 45 emojis animales distintos que representan el tipo de animal correspondiente. No se incluyen huellas ni objetos. Para evitar símbolos incorrectos o repetidos se sustituyeron morsa, orca, ajolote, camaleón, tucán y colibrí por alce, ballena jorobada, pez globo, escarabajo rinoceronte, cisne y pavo silvestre. No existe un emoji exclusivo para cada especie zoológica: 🦊 identifica un zorro y 🐋 una ballena, sin especificar especie o color. [Unicode permite presentaciones diferentes entre plataformas](https://www.unicode.org/reports/tr51/). Se usan los caracteres nativos sin distribuir imágenes ni la fuente de Apple. Los nuevos animales deben elegir un emoji animal disponible; la correspondencia entre su nombre y ese emoji la define el usuario.

## Uso en el entrenamiento

Cada fila contiene exactamente veinte valores finitos entre 0 y 1. No se incluye el nombre, emoji, nombre científico ni ecosistema como entrada. No hay datos faltantes ni categorías libres en los rasgos; los nombres duplicados se rechazan después de normalizar mayúsculas y Unicode.

No se aplica una normalización adicional por desviación estándar porque todas las columnas ya usan escalas documentadas en [0, 1]. Las veinte características tienen el mismo peso numérico. Esto no significa igual importancia biológica: tamaño y masa están relacionados, al igual que endotermia y pelaje o plumaje. Esas correlaciones influyen en la geometría aprendida.

El SOM compara números y supone una geometría entre categorías. La distancia entre dos niveles consecutivos es una decisión de modelado; en un estudio científico habría que validar escalas, valores, redundancia y pesos. La codificación entregada satisface las escalas solicitadas y permite explicar sus consecuencias.

## Fuentes consultadas

- [Canis lupus en Animal Diversity Web](https://animaldiversity.org/accounts/Canis_lupus/): descripción, vida en grupo, pelaje y alimentación del lobo gris.
- [Aptenodytes forsteri en Animal Diversity Web](https://animaldiversity.org/accounts/Aptenodytes_forsteri/): pingüino emperador como ave de ambiente polar.
- [Octopus vulgaris en Animal Diversity Web](https://animaldiversity.org/accounts/Octopus_vulgaris/): pulpo como invertebrado marino.
- [Danaus plexippus en Animal Diversity Web](https://animaldiversity.org/accounts/Danaus_plexippus/): mariposa monarca, locomoción y alimentación.
- [Glaucomys volans en Animal Diversity Web](https://animaldiversity.org/accounts/Glaucomys_volans/): ardilla voladora, ambiente forestal y desplazamiento por planeo.
- [Aphonopelma chalcodes en Animal Diversity Web](https://animaldiversity.org/accounts/Aphonopelma_chalcodes/): tarántula de ambientes desérticos, actividad nocturna y longevidad potencial.

Para corregir una categoría, edita el índice correspondiente en `data/build_dataset.py`, ejecuta `python data/build_dataset.py` y regenera los resultados con `python export_result.py`. Una modificación del dataset puede cambiar las métricas, los vecinos y las coordenadas del mapa.
