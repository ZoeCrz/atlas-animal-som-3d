# Publicar Atlas animal con GitHub Pages

Publicado: [abrir Atlas animal](https://zoecrz.github.io/atlas-animal-som-3d/). Repositorio: [ZoeCrz/atlas-animal-som-3d](https://github.com/ZoeCrz/atlas-animal-som-3d). GitHub Pages usa `main` y `/ (root)`. El despliegue inicial del commit `5946fec` finalizó correctamente: [ejecución de Pages](https://github.com/ZoeCrz/atlas-animal-som-3d/actions/runs/36967940473).

## Publicación desde el navegador

1. Entra a [GitHub](https://github.com/login) con tu cuenta.
2. Crea un repositorio público llamado **atlas-animal-som-3d**, con la descripción “Mapa autoorganizado 3D de 45 animales, con Python ejecutado en el navegador”. Puedes inicializarlo con un README.
3. En **Add file → Upload files**, sube `index.html` y `.nojekyll` a la raíz. Para publicar únicamente la app son los únicos archivos necesarios.
4. Si deseas entregar también el código, sube los módulos Python, `web/`, `data/animales.json`, `data/animales.csv`, `data/build_dataset.py`, las pruebas y documentación. Conserva las carpetas. No publiques el documento original, la captura con información académica personal, cachés ni entornos.
5. En **Settings → Pages**, selecciona **Deploy from a branch**, rama **main**, carpeta **/ (root)** y **Save**.
6. Espera a que GitHub muestre la URL y abre **Visit site**. Esa será la dirección que debes compartir.
7. Comprueba que aparezca “Listo para explorar y entrenar”; cambia las épocas y entrena; agrega un animal con sus 20 rasgos. La URL del repositorio muestra código; la URL de Pages abre la aplicación.

Estas instrucciones siguen la [guía oficial de creación de un sitio en GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site). La URL indicada arriba fue obtenida de la ejecución real de GitHub Pages y se abrió en Chrome.

## Actualizar el sitio

Tras modificar los datos o el código, ejecuta `python export_result.py` y sustituye `index.html` en el repositorio. GitHub Pages volverá a publicar la rama configurada. Si agregas animales desde la interfaz, se guardan en tu navegador, no en el repositorio ni en los navegadores de otros visitantes.
