"""Dataset y tablas para la aplicación local."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from features import FEATURES, ECOSYSTEMS, EMOJIS
from animal_validation import (normalized_name, validate_animal, validate_collection,
                               export_custom, import_custom, MAX_CUSTOM_ANIMALS)

BASE_PATH = Path(__file__).parent / "data" / "animales.json"

def load_base() -> list[dict]:
    animals = validate_collection(json.loads(BASE_PATH.read_text(encoding="utf-8")))
    if len(animals) != 45:
        raise ValueError("El dataset base debe contener exactamente 45 animales.")
    return animals


def matrix(animals: list[dict]) -> np.ndarray:
    return np.asarray([a["features"] for a in animals], dtype=float)


def records(animals: list[dict], readable: bool = False) -> pd.DataFrame:
    rows = []
    for animal in animals:
        row = {"Animal": animal["name"], "Emoji": animal["emoji"], "Ecosistema": animal["ecosystem"],
               "Nombre científico": animal.get("scientific_name", "")}
        for f, v in zip(FEATURES, animal["features"]):
            row[f.label] = f.options[f.scale.index(v)] if readable else v
        rows.append(row)
    return pd.DataFrame(rows)


