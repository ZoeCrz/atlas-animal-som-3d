"""Genera el JSON y CSV desde categorías legibles por índice.

Cada fila contiene 15 índices ordinales y 5 índices binarios en el orden de FEATURES.
Los índices son decisiones didácticas aproximadas, no mediciones zoológicas.
Ejecutar desde la raíz: python data/build_dataset.py
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from features import FEATURES

ROWS = [
    # Nombre, emoji, ecosistema de referencia, nombre científico, categorías de los 20 rasgos.
    ("Lobo gris", "🐺", "Bosque templado", "Canis lupus", [3,3,2,2,1,0,0,4,2,0,1,2,1,3,1,1,1,0,1,0]),
    ("Zorro ártico", "🦊", "Ártico", "Vulpes lagopus", [2,2,2,2,1,0,0,4,2,1,0,1,1,4,1,1,1,0,1,0]),
    ("Reno", "🦌", "Ártico", "Rangifer tarandus", [3,4,2,2,1,0,0,4,3,4,1,3,0,4,1,1,1,0,1,0]),
    ("Bisonte americano", "🦬", "Pradera", "Bison bison", [3,4,3,2,1,0,0,4,2,4,1,3,0,3,1,1,1,0,1,0]),
    ("Dromedario", "🐪", "Desierto", "Camelus dromedarius", [3,4,4,2,0,0,0,4,1,4,1,2,0,1,0,1,1,0,1,0]),
    ("Canguro rojo", "🦘", "Pradera", "Macropus rufus", [3,3,3,1,0,0,0,4,2,4,1,2,1,1,0,1,1,0,1,0]),
    ("Ardilla voladora del sur", "🐿️", "Bosque templado", "Glaucomys volans", [1,0,2,2,0,1,2,2,1,3,1,2,2,2,1,1,1,0,1,0]),
    ("Erizo europeo", "🦔", "Bosque templado", "Erinaceus europaeus", [1,2,2,2,1,0,1,2,1,1,0,0,2,2,1,1,1,0,1,0]),
    ("Nutria europea", "🦦", "Agua dulce", "Lutra lutra", [2,2,2,2,2,0,1,3,4,0,2,0,1,3,3,1,1,0,1,0]),
    ("Castor americano", "🦫", "Agua dulce", "Castor canadensis", [2,3,3,2,2,0,0,2,4,4,1,2,2,3,3,1,1,0,1,0]),
    ("Foca común", "🦭", "Costa", "Phoca vitulina", [3,4,3,0,3,0,0,1,4,0,1,2,1,3,3,1,1,0,1,0]),
    ("Alce", "🫎", "Ártico", "Alces alces", [3,4,3,2,1,0,0,4,3,4,1,1,1,4,2,1,1,0,1,0]),
    ("Pingüino emperador", "🐧", "Antártico", "Aptenodytes forsteri", [3,3,3,1,2,0,0,2,4,0,2,3,0,4,3,1,1,1,0,1]),
    ("Delfín nariz de botella", "🐬", "Océano", "Tursiops truncatus", [3,4,4,0,4,0,0,0,4,0,1,2,0,2,3,1,1,0,0,0]),
    ("Ballena azul", "🐋", "Océano", "Balaenoptera musculus", [4,4,4,0,4,0,0,0,4,0,3,1,0,3,3,1,1,0,0,0]),
    ("Ballena jorobada", "🐳", "Océano", "Megaptera novaeangliae", [4,4,4,0,4,0,0,0,4,0,2,1,0,3,3,1,1,0,0,0]),
    ("Tiburón blanco", "🦈", "Océano", "Carcharodon carcharias", [4,4,4,0,4,0,0,0,4,0,1,0,1,2,3,0,1,0,0,0]),
    ("Pez payaso", "🐠", "Océano", "Amphiprion ocellaris", [0,0,2,0,4,0,0,0,4,2,1,2,0,0,3,0,1,1,0,0]),
    ("Pulpo común", "🐙", "Océano", "Octopus vulgaris", [2,2,1,0,4,0,0,0,3,0,1,0,2,1,3,0,0,1,0,0]),
    ("Calamar común", "🦑", "Océano", "Loligo vulgaris", [1,1,0,0,4,0,0,0,4,0,1,2,1,1,3,0,0,1,0,0]),
    ("Medusa luna", "🪼", "Océano", "Aurelia aurita", [1,1,1,0,4,0,0,0,1,0,2,0,1,2,3,0,0,1,0,0]),
    ("Cangrejo verde", "🦀", "Costa", "Carcinus maenas", [0,0,1,4,3,0,0,2,2,2,0,0,2,2,3,0,0,1,0,0]),
    ("Langosta americana", "🦞", "Océano", "Homarus americanus", [1,2,4,4,4,0,0,0,2,1,0,0,2,3,3,0,0,1,0,0]),
    ("Tortuga verde", "🐢", "Océano", "Chelonia mydas", [3,4,4,2,3,0,0,1,4,4,2,0,0,1,3,0,1,1,0,0]),
    ("Cocodrilo del Nilo", "🐊", "Agua dulce", "Crocodylus niloticus", [4,4,4,2,2,0,0,3,4,0,1,1,1,1,3,0,1,1,0,0]),
    ("Pez globo moteado", "🐡", "Agua dulce", "Dichotomyctere nigroviridis", [1,1,2,0,4,0,0,0,3,1,1,0,0,0,3,0,1,1,0,0]),
    ("Rana de ojos rojos", "🐸", "Selva tropical", "Agalychnis callidryas", [0,0,1,2,2,0,2,2,2,0,2,0,2,0,3,0,1,1,0,0]),
    ("Iguana verde", "🦎", "Selva tropical", "Iguana iguana", [3,2,3,2,1,0,2,3,3,4,1,0,0,0,2,0,1,1,0,0]),
    ("Escarabajo rinoceronte", "🪲", "Selva tropical", "Oryctes rhinoceros", [0,0,1,3,0,2,2,2,0,4,2,0,2,0,2,0,0,1,0,0]),
    ("Pitón reticulada", "🐍", "Selva tropical", "Malayopython reticulatus", [4,3,3,0,1,0,2,2,3,0,1,0,2,0,2,0,1,1,0,0]),
    ("Águila real", "🦅", "Aéreo", "Aquila chrysaetos", [2,2,3,1,0,2,0,2,1,0,1,1,0,3,0,1,1,1,0,1]),
    ("Búho real", "🦉", "Aéreo", "Bubo bubo", [2,2,3,1,0,2,0,2,1,0,1,1,2,3,1,1,1,1,0,1]),
    ("Guacamaya roja", "🦜", "Selva tropical", "Ara macao", [2,2,4,1,0,2,2,2,0,4,1,2,0,0,2,1,1,1,0,1]),
    ("Cisne blanco", "🦢", "Agua dulce", "Cygnus olor", [3,3,3,1,2,2,0,2,3,4,1,1,0,3,3,1,1,1,0,1]),
    ("Flamenco común", "🦩", "Costa", "Phoenicopterus roseus", [3,2,4,1,2,2,0,2,2,1,2,3,0,2,3,1,1,1,0,1]),
    ("Pavo real", "🦚", "Selva tropical", "Pavo cristatus", [3,2,3,1,0,2,1,3,0,2,0,2,0,1,1,1,1,1,0,1]),
    ("Pavo silvestre", "🦃", "Bosque templado", "Meleagris gallopavo", [3,2,2,1,0,2,1,3,1,3,0,2,0,2,1,1,1,1,0,1]),
    ("Murciélago frugívoro", "🦇", "Selva tropical", "Artibeus jamaicensis", [0,0,2,1,0,2,1,1,0,4,2,2,2,0,2,1,1,0,1,0]),
    ("Perezoso de tres dedos", "🦥", "Selva tropical", "Bradypus variegatus", [2,2,3,2,1,0,2,1,2,4,2,0,1,0,2,1,1,0,1,0]),
    ("Mariposa monarca", "🦋", "Aéreo", "Danaus plexippus", [0,0,0,3,0,2,1,1,0,4,2,0,0,1,1,0,0,1,0,0]),
    ("Abeja melífera", "🐝", "Pradera", "Apis mellifera", [0,0,0,3,0,2,1,2,0,4,2,3,0,2,1,0,0,1,0,0]),
    ("Hormiga cortadora", "🐜", "Selva tropical", "Atta cephalotes", [0,0,0,3,0,0,2,2,0,4,3,3,0,0,2,0,0,1,0,0]),
    ("Tarántula del desierto", "🕷️", "Desierto", "Aphonopelma chalcodes", [0,0,3,4,0,0,1,2,0,0,2,0,2,1,0,0,0,1,0,0]),
    ("Escorpión emperador", "🦂", "Selva tropical", "Pandinus imperator", [1,0,2,4,0,0,1,2,0,0,2,0,2,0,2,0,0,0,0,0]),
    ("Caracol de jardín", "🐌", "Bosque templado", "Cornu aspersum", [0,0,1,0,0,0,2,1,0,4,1,0,2,2,2,0,0,1,0,0]),
]


def build():
    animals = []
    for name, emoji, ecosystem, scientific, levels in ROWS:
        assert len(levels) == len(FEATURES), name
        animals.append({"name": name, "emoji": emoji, "ecosystem": ecosystem,
                        "scientific_name": scientific,
                        "features": [f.scale[level] for f, level in zip(FEATURES, levels)]})
    folder = Path(__file__).parent
    (folder / "animales.json").write_text(json.dumps(animals, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    from dataset import records, load_base
    records(load_base()).to_csv(folder / "animales.csv", index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    build()
